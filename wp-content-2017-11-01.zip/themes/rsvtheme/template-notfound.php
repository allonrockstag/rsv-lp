<article id="post-not-found" class="search-not-found hentry cf">
	<header class="article-header">
		<h1><?php _e( 'Sorry!', 'bonestheme' ); ?></h1>
		<h2><?php _e( 'We could not find a result for you.', 'bonestheme' ); ?></h2>
	</header>
	<section class="entry-content">
		<p>Can't find what you're looking for? Try looking again!<br/>Or go back to our <a href="<?php echo home_url(); ?>" rel="nofollow">Home Page</a>.</p>
	</section>

</article>