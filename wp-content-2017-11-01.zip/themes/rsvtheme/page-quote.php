<?php
/*
Template Name: Get a Quote
*/
?>

<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<?php 	
	$quotedesc = get_post_meta($post->ID, 'wpcf-quote-description', true);
	$quoteform = get_post_meta($post->ID, 'wpcf-quote-form', true);

?>

<?php endwhile; ?>
<?php else : ?>		
<?php endif; ?>
			
			
			<div id="content" class="contentgrey">
			<div class="standard-header careers-header">
				<div id="inner-content" class="wrap wrap-small cf">
					<div class="m-all t-all d-all cf">
						<div class="home-title scrollme animateme"
						data-when="span"
					    data-from="1"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="20">
						<h1 class="page-title" itemprop="headline">Get a <span>Quote</span></h1>
						</div>
					</div>
				</div>
			</div>
			
			
				
				
				<section class="quote" id="getquote">
					<div id="inner-content" class="wrap wrap-tiny cf">
					<div class="quote-container">
					

						<main id="main" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

									
										<?php the_content(); ?>
									

							</article>

							<?php endwhile; ?>
								
							<?php else : ?>

								<?php endif; ?>

						</main>
						
						
						<div class="quote-form">
						
						<?php echo apply_filters('the_content',$quotedesc); ?>
						<?php echo apply_filters('the_content',$quoteform); ?>
						</div>
					
					
					
					</div>
					</div>
					
				</section>	
					
				
		
		
		
			
			<div class="dot-separator"></div>
			
			<section class="careers-bottom">
				<div id="inner-content" class="wrap wrap-small cf">
					<div class="m-all t-all d-all cf">
							<div class="share-box">
								<h3>Share This</h3>
							<ul class="footer-social">
								<li class="footer-icon"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.linkedin.com/cws/share?url=<?php echo get_permalink(); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							
							</ul>
							</div>
					</div>
				</div>
			</section>
			
				

			</div>


<script>
	// init controller
	var controller = new ScrollMagic.Controller();


		
	var tween1 = TweenMax.to("#animatelist1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween2 = TweenMax.to("#animatelist2", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween3 = TweenMax.to("#animatelist3", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	
	var vidHero = document.getElementById('vidhero');
	var $vh = $('#vidhero');

	
	// build scene
				var scene1 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist1",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
					
				var scene2 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist2",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
					
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist3",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);	
					
				var scene4 = new ScrollMagic.Scene({triggerElement: "#triggervid1", duration: 800, offset: 400})
						.setPin("#pin1")
						.addTo(controller);
			
				var scene5 = new ScrollMagic.Scene({triggerElement: "#vidhero", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 vidHero.play();
				
					})
				
	

	</script>
<?php get_footer(); ?>

