<?php 
	$design = get_post_meta($post->ID, 'wpcf-article-design', true);  
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	?>
              <?php
                /*
                 * This is the default post format.
                 *
                 * So basically this is a regular post. if you don't want to use post formats,
                 * you can just copy ths stuff in here and replace the post format thing in
                 * single.php.
                 *
                 * The other formats are SUPER basic so you can style them as you like.
                 *
                 * Again, If you want to remove post formats, just delete the post-formats
                 * folder and replace the function below with the contents of the "format.php" file.
                */
              ?>
			  
			  	
			  	
				 
              <article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?> role="article">
	              
            

				
				
				<div class="m-all t-all d-all cf post-article">
					
			
								

    		
	                <?php echo wp_get_attachment_image( $post->ID , array('700', '600'), "", array( "class" => "img-responsive" ) );  ?>
					
	                <?php if(has_post_thumbnail()) { ?>
	                
	                
	                <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 

		                $featuredImageAlt = get_post_meta( get_post_thumbnail_id($post->ID) );
		                $imageAlt = $featuredImageAlt['_wp_attachment_image_alt']['0']; // Display Alt text
		                $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "large" );
 						$image_width = $image_data[1]; 
						$image_height = $image_data[2]; 
	                ?> 
				                   <img class="article-feature-img" src="<?php echo $featuredImage; ?>" alt="<?php echo $imageAlt; ?>">
				              
				      <?php } ?>
				      
				      
			            <?php if(has_post_thumbnail()) { ?>
		      
						   <img class="article-feature-img-mobile" src="<?php echo $featuredImage; ?>" alt="<?php echo $imageAlt; ?>">
						<?php } ?>

				
		
			  	
			  	<div class="m-all t-all d-all cf">
		
					 <section class="entry-content cf" itemprop="mainContentOfPage" content="WebPageElement">
	        
	               
                  <?php the_content(); ?>

                </section> <?php // end article section ?>
                
			  	</div>
			  	
               
                
                
				</div>
                 
            
                 	
                 	
                 <div class="m-all t-all d-all cf">
                <footer id="apply" class="article-footer">

					<div class="dot-separator"></div>
						<div class="career-form-container">
							<div class="career-form individual">
								<h3>Apply for Position</h3>
									<h2><?php the_title();?></h2>
									<hr>
								<?php echo do_shortcode( '[contact-form-7 id="138" title="Careers Form Individual"]' ); ?>
							</div>
						</div>
              

                </footer> <?php // end article footer ?>
			  	</div>
                 
                 

              </article> <?php // end article ?>
              
              
			
			 
			 
		 	