<?php if (have_posts()) : while (have_posts()) : the_post();
	$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	
	$articledesign = get_post_meta($post->ID, 'wpcf-blog-article-design', true);
	$titlecolor = get_post_meta($post->ID, 'wpcf-blog-title-color', true);
	
	$loop = new WP_Query( array( 'post_type' => array('project'), 'posts_per_page' => 3, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) );
	
	?>

	
	<?php if(($articledesign == 2) && ($titlecolor == 1)) { ?> <!-- Hero Image with White Text -->
					<?php get_header('white'); ?>
					
			<?php } else if(($articledesign == 2) && ($titlecolor == 2)) { ?> <!-- Hero Image with Black Text -->
					<?php get_header(); ?>
			<?php } else { ?>
					<?php get_header(); ?>
			<?php } ?>
			
			
							
			<div id="content" class="contentgrey nopadding">
			
			
			
						
			<?php if(($articledesign == 2) && ($titlecolor == 1)) { ?> <!-- Hero Image with White Text -->
			<div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-translatey="-40">	
				<header class="blog-article-header dark">
					
			<?php } else if(($articledesign == 2) && ($titlecolor == 2)) { ?> <!-- Hero Image with Black Text -->
			<div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-translatey="-40">	
				<header class="blog-article-header dark black">
			<?php } else { ?>
				<header class="blog-article-header">
			<?php } ?>
			
			
			<?php if($articledesign == 2) { ?>
			 	
				
				
				<?php if(has_post_thumbnail()) { ?>
	                
	                
	                <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
		                $featuredImageAlt = get_post_meta( get_post_thumbnail_id($post->ID) );
		                $imageAlt = $featuredImageAlt['_wp_attachment_image_alt']['0']; // Display Alt text
		                $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "large" );
 						$image_width = $image_data[1]; 
						$image_height = $image_data[2]; 
	                ?> 
	                
	                <div class="blog-article-hero" style="background-image: url(<?php echo $featuredImage; ?>)" alt="<?php echo $imageAlt; ?>"><span></span></div>
				                  
				      <?php } else { ?>
					      <div class="blog-article-hero"><span></span></div>
					     <?php }  ?>
				      
				      
			 
			<?php } ?>
			
			
					<div id="inner-content" class="wrap cf">	
						
               <?php if($articledesign == 2) { ?>
                <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-scale="0.95"
						data-translatey="-20">
				<?php } else { ?>	
					<div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
							data-scale="0.95"
						data-translatey="40">
				<?php } ?>		
                  <h1 class="entry-title single-title" itemprop="headline" rel="bookmark"><?php the_title(); ?></h1>
                </div>
                
                <?php if($articledesign == 2) { ?>
                <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-scale="0.95"
						data-translatey="-20">
				<?php } else { ?>	
					<div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
							data-scale="0.95"
						data-translatey="40">
				<?php } ?>
				  <?php if ( has_excerpt() ) { ?>
					    <p class="excerpt" itemprop="description"><?php echo get_the_excerpt(); ?></p>
					<?php } else { ?>
					    
					<?php } ?>
					
                </div>
				
				
					<?php if($articledesign == 2) { ?>
                <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-scale="0.95"
						data-translatey="-30">
				<?php } else { ?>	
					<div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
							data-scale="0.95"
						data-translatey="20">
				<?php } ?>
					  <h4><?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
											
													echo '<span class="cat">' . $term->name . '</span>';
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
											
											<span class="author">	
												<?php $author = get_the_author(); ?>
												<?php if($author == 'admin'){ ?>		
													RSV
												<?php } else { ?>
													<?php echo $author; ?>
												<?php } ?>
											</span>
				

											<span class="date" datetime="<?php get_the_time('Y-m-d')?>" itemprop="datePublished"><?php the_time('F j, Y'); ?></span>
				
				</h4>
				
					 </div>
											
											
				
				
				
						
					</div>
					
					
					<div class="home-1-content scrollme animateme"
						data-when="enter"
					    data-from="1"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
							data-scale="0.95"
						data-translatey="30">
					  <?php echo wp_get_attachment_image( $post->ID , array('700', '600'), "", array( "class" => "img-responsive" ) );  ?>
					
	                <?php if(has_post_thumbnail()) { ?>
	                
	                
	                <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
		                $featuredImageAlt = get_post_meta( get_post_thumbnail_id($post->ID) );
		                $imageAlt = $featuredImageAlt['_wp_attachment_image_alt']['0']; // Display Alt text
		                $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "large" );
 						$image_width = $image_data[1]; 
						$image_height = $image_data[2]; 
	                ?> 
				                   <img class="blog-article-feature-img" src="<?php echo $featuredImage; ?>" alt="<?php echo $imageAlt; ?>">
				      <?php } ?>
				      
					</div>
				      
				      
                </header> <?php // end article header ?>
                
                
                <?php if(($articledesign == 2) && ($titlecolor == 1)) { ?> <!-- Hero Image with White Text -->
			</div>
					
			<?php } else if(($articledesign == 2) && ($titlecolor == 2)) { ?> <!-- Hero Image with Black Text -->
			</div>
			<?php } else { ?>
			
			<?php } ?>
			
			
			
				
							
	<?php endwhile; ?>
<?php else : ?>
<?php endif; ?>

			
	            		  
										
										
										
						<div id="inner-content" class="wrap wrap-tiny cf">	
							
					
						<main id="main" role="main">
				

							<?php if (have_posts()) : while (have_posts()) : the_post();
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
								$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
								$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
								$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
								$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
								$headertype = get_post_meta($post->ID, 'wpcf-header-type', true);
								$post_type_name = get_post_type( $post->ID );
								$post_type = get_post_type_object( get_post_type($post) );
								$embed_code = wp_oembed_get($vidyoutube);
								$embed_code2 = wp_oembed_get($vidvimeo);
								$titlefonts = get_post_meta($post->ID, 'wpcf-article-title-fonts', true);
								$titlecolor = get_post_meta($post->ID, 'wpcf-article-title-color', true);
								$bgshadow = get_post_meta($post->ID, 'wpcf-background-shadow', true);						
							?>
						 
							
								<?php get_template_part( 'post-formats/format-blog', get_post_format() ); 	?>
							

							
							<div class="post-bottom-bar">
								<ul class="post-share-mobile">
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
					  	<li class="share-linkedin"><a href="https://www.linkedin.com/cws/share?url=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
<li class="share-comment"><a href="#comment"><span>Comments</span></a></li>


				  	</ul>
							</div>

						<?php endwhile; ?>

						<?php else : ?>

						<?php endif; ?>

						
						
								</main>
								</div>
				

			</div> <!-- end #content -->
			

			<!-- Root element of PhotoSwipe. Must have class pswp. -->
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

    <!-- Background of PhotoSwipe. 
         It's a separate element as animating opacity is faster than rgba(). -->
    <div class="pswp__bg"></div>

    <!-- Slides wrapper with overflow:hidden. -->
    <div class="pswp__scroll-wrap">

        <!-- Container that holds slides. 
            PhotoSwipe keeps only 3 of them in the DOM to save memory.
            Don't modify these 3 pswp__item elements, data is added later on. -->
        <div class="pswp__container">
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
        </div>

        <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
        <div class="pswp__ui pswp__ui--hidden">

            <div class="pswp__top-bar">

                <!--  Controls are self-explanatory. Order can be changed. -->

                <div class="pswp__counter"></div>

                <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>

                <button class="pswp__button pswp__button--share" title="Share"></button>

                <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>

                <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>

                <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
                <!-- element will get class pswp__preloader--active when preloader is running -->
                <div class="pswp__preloader">
                    <div class="pswp__preloader__icn">
                      <div class="pswp__preloader__cut">
                        <div class="pswp__preloader__donut"></div>
                      </div>
                    </div>
                </div>
            </div>

            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                <div class="pswp__share-tooltip"></div> 
            </div>

            <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
            </button>

            <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
            </button>

            <div class="pswp__caption">
                <div class="pswp__caption__center"></div>
            </div>

        </div>

    </div>

</div>


<?php $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "full" ); ?>
<?php $image_width = $image_data[1]; ?>
<?php $image_height = $image_data[2]; ?>
<?php $author = get_the_author(); ?>

<script type="application/ld+json">

{
  "@context": "http://schema.org",
  "@type": "NewsArticle",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "<?php the_ID(); ?>"
  },
  "headline": "<?php the_title(); ?>",
  "image": {
    "@type": "ImageObject",
    "url": "<?php echo $featuredImage; ?>",
    "height": <?php echo $image_height; ?>,
    "width": <?php echo $image_width; ?>
  },
  "datePublished": "<?php the_time('F j, Y'); ?>",
  "dateModified": "<?php the_modified_date('F j, Y'); ?>",
  "author": {
    "@type": "Person",
    "name": "<?php echo $author; ?>"
  },
  "publisher": {
    "@type": "Organization",
    "name": "Foxesden",
    "logo": {
      "@type": "ImageObject",
      "url": "https://foxesden.co/wp-content/themes/foxesdentheme/library/images/foxesden-logo-amp.png",
      "width": 600,
      "height": 60
    }
  },
  "description": "<?php echo get_the_excerpt(); ?>"
}


</script>

<script>
	
	
	var airpodVid = document.getElementById('airpods');
	var $lv = $('#airpods');

	// init controller
	var controller = new ScrollMagic.Controller();
	
	// build scene
	var scene = new ScrollMagic.Scene({triggerElement: "#airpods", duration: 0 })
					.addTo(controller)
					.addIndicators() // add indicators (requires plugin)
										
					.on("enter", function () {
						if(!$lv.hasClass('hasplayed')){
							 airpodVid.play();
							 $lv.addClass('hasplayed');
						} else {
							
						}
						
					})
					
				//.on("leave", function () {
				//		airpodVid.pause();
				//	 })
				
</script>



<?php get_footer(); ?>


