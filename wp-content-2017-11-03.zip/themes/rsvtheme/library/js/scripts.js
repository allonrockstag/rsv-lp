/*
 * Bones Scripts File
 * Author: Eddie Machado
 *
 * This file should contain any js scripts you want to add to the site.
 * Instead of calling it in the header or throwing it inside wp_head()
 * this file will be called automatically in the footer so as not to
 * slow the page load.
 *
 * There are a lot of example functions and tools in here. If you don't
 * need any of it, just remove it. They are meant to be helpers and are
 * not required. It's your world baby, you can do whatever you want.
*/


/*
 * Get Viewport Dimensions
 * returns object with viewport dimensions to match css in width and height properties
 * ( source: http://andylangton.co.uk/blog/development/get-viewport-size-width-and-height-javascript )
*/
function updateViewportDimensions() {
	var w=window,d=document,e=d.documentElement,g=d.getElementsByTagName('body')[0],x=w.innerWidth||e.clientWidth||g.clientWidth,y=w.innerHeight||e.clientHeight||g.clientHeight;
	return { width:x,height:y };
}
// setting the viewport width
var viewport = updateViewportDimensions();


/*
 * Throttle Resize-triggered Events
 * Wrap your actions in this function to throttle the frequency of firing them off, for better performance, esp. on mobile.
 * ( source: http://stackoverflow.com/questions/2854407/javascript-jquery-window-resize-how-to-fire-after-the-resize-is-completed )
*/
var waitForFinalEvent = (function () {
	var timers = {};
	return function (callback, ms, uniqueId) {
		if (!uniqueId) { uniqueId = "Don't call this twice without a uniqueId"; }
		if (timers[uniqueId]) { clearTimeout (timers[uniqueId]); }
		timers[uniqueId] = setTimeout(callback, ms);
	};
})();

// how long to wait before deciding the resize has stopped, in ms. Around 50-100 should work ok.
var timeToWaitForLast = 100;


/*
 * Here's an example so you can see how we're using the above function
 *
 * This is commented out so it won't work, but you can copy it and
 * remove the comments.
 *
 *
 *
 * If we want to only do it on a certain page, we can setup checks so we do it
 * as efficient as possible.
 *
 * if( typeof is_home === "undefined" ) var is_home = $('body').hasClass('home');
 *
 * This once checks to see if you're on the home page based on the body class
 * We can then use that check to perform actions on the home page only
 *
 * When the window is resized, we perform this function
 * $(window).resize(function () {
 *
 *    // if we're on the home page, we wait the set amount (in function above) then fire the function
 *    if( is_home ) { waitForFinalEvent( function() {
 *
 *	// update the viewport, in case the window size has changed
 *	viewport = updateViewportDimensions();
 *
 *      // if we're above or equal to 768 fire this off
 *      if( viewport.width >= 768 ) {
 *        console.log('On home page and window sized to 768 width or more.');
 *      } else {
 *        // otherwise, let's do this instead
 *        console.log('Not on home page, or window sized to less than 768.');
 *      }
 *
 *    }, timeToWaitForLast, "your-function-identifier-string"); }
 * });
 *
 * Pretty cool huh? You can create functions like this to conditionally load
 * content and other stuff dependent on the viewport.
 * Remember that mobile devices and javascript aren't the best of friends.
 * Keep it light and always make sure the larger viewports are doing the heavy lifting.
 *
*/

/*
 * We're going to swap out the gravatars.
 * In the functions.php file, you can see we're not loading the gravatar
 * images on mobile to save bandwidth. Once we hit an acceptable viewport
 * then we can swap out those images since they are located in a data attribute.
*/
function loadGravatars() {
  // set the viewport using the function above
  viewport = updateViewportDimensions();
  // if the viewport is tablet or larger, we load in the gravatars
  if (viewport.width >= 768) {
  jQuery('.comment img[data-gravatar]').each(function(){
    jQuery(this).attr('src',jQuery(this).attr('data-gravatar'));
  });
	}
} // end function


/*
 * Put all your regular jQuery in here.
*/
jQuery(document).ready(function($) {

  /*
   * Let's fire off the gravatar function
   * You can remove this if you don't need it
  */
  loadGravatars();
  
 


/* Smooth Scrolling */

  $(function(){
    $("a[href*=#container],a[href*=#comment],a[href*=#subscribe],a[href*=#form],a[href*=#apply]").click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
        && location.hostname == this.hostname) {
            var $target = $(this.hash);
            $target = $target.length && $target || $('[name=' + this.hash.slice(1) +']');
            if ($target.length) {
                var targetOffset = $target.offset().top - 60;
                $('html,body').animate({scrollTop: targetOffset}, 300);
                return false;
            }
        }
    });
});

  $(function(){
    $("a[href*=#thearticle],a[href*=#content]").click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
        && location.hostname == this.hostname) {
            var $target = $(this.hash);
            $target = $target.length && $target || $('[name=' + this.hash.slice(1) +']');
            if ($target.length) {
                var targetOffset = $target.offset().top;
                $('html,body').animate({scrollTop: targetOffset}, 300);
                return false;
            }
        }
    });
});


 $(document).keyup(function(event) {
	    if (event.keyCode === 27) {
	        $(".md-close").click();
	        $('.mobile-nav li').removeClass('menu-visible');
		    $('.mobile-nav li').addClass('menu-not-visible');
			$('.md-bg-container').removeClass('bg-on');
			$('.md-bg-container').addClass('bg-off');
			$('.social-nav').removeClass('social-nav-on');
			$('.social-nav').addClass('social-nav-off');
	    }
	});

$(document).ready(function() {
  


 // external js: flickity.pkgd.js

var $carousel = $('.main-carousel-workflow').flickity({
  contain: true,
  autoPlay: 8000,
  contain: true,
  selectedAttraction: 0.02,
  friction: 0.8,
  pauseAutoPlayOnHover: true,
  dragThreshold: 15,
  prevNextButtons: false,
  pageDots: false,
  draggable: false
});



$('.button-group').on( 'click', '.button', function() {
  var index = $(this).index();
  $carousel.flickity( 'select', index );
  $carousel.flickity('pausePlayer');
  	


});


$(".button-group").hover(function(){
    $carousel.flickity('pausePlayer');
    }, function(){
    $carousel.flickity('playPlayer');
});





$carousel.on( 'select.flickity', function() {
  if ($('.carousel-cell-1').hasClass('is-selected')) {
		$('.button-1').addClass('is-selected');
		$('.button-2').removeClass('is-selected');
		$('.button-3').removeClass('is-selected');
		$('.line-pre').addClass('is-selected');
		$('.line-pro').removeClass('is-selected');
		$('.line-post').removeClass('is-selected');
		$('.fgline14').addClass('select-1');
		$('.fgline14').removeClass('select-2');
		$('.fgline14').removeClass('select-3');
	} else if ($('.carousel-cell-2').hasClass('is-selected')) {
		$('.button-1').removeClass('is-selected');
		$('.button-2').addClass('is-selected');
		$('.button-3').removeClass('is-selected');
		$('.line-pre').removeClass('is-selected');
		$('.line-pro').addClass('is-selected');
		$('.line-post').removeClass('is-selected');
		$('.fgline14').removeClass('select-1');
		$('.fgline14').addClass('select-2');
		$('.fgline14').removeClass('select-3');
	} else if ($('.carousel-cell-3').hasClass('is-selected')) {
		$('.button-1').removeClass('is-selected');
		$('.button-2').removeClass('is-selected');
		$('.button-3').addClass('is-selected');
		$('.line-pre').removeClass('is-selected');
		$('.line-pro').removeClass('is-selected');
		$('.line-post').addClass('is-selected');
		$('.fgline14').removeClass('select-1');
		$('.fgline14').removeClass('select-2');
		$('.fgline14').addClass('select-3');
	}
  
})

$(function(){
    $("#searchtrigger").click(function() {
    	if($('.md-modal').hasClass('md-show')) {
			$('.md-bg-container').addClass('bg-on');
			$('.social-nav').removeClass('social-nav-off');
			$('.social-nav').addClass('social-nav-on');
			$('.md-bg-container').removeClass('bg-off');
			$('.mobile-nav li').removeClass('menu-not-visible');
			$('.mobile-nav li').addClass('menu-visible');
		} 
    });
    
    $(".md-close").click(function() {
	    
	    if((!$('.md-modal').hasClass('md-show'))) {
	    $('.mobile-nav li').removeClass('menu-visible');
	    $('.mobile-nav li').addClass('menu-not-visible');
		$('.md-bg-container').removeClass('bg-on');
		$('.md-bg-container').addClass('bg-off');
		$('.social-nav').removeClass('social-nav-on');
		$('.social-nav').addClass('social-nav-off');
	    }
    	
    });
});









//STICKY FUNCTION


		
//var stickyNavTop = $('.checkout-orderdetails').offset().top;
var stickyNavTop = 350;
var stickyNavTop2 = 140;

var topHalf = $(document).height()*0.3;
var topSpace = $('.standard-header').height() + 60 + 45;
var topSpace2 = $('.standard-header').height() + 60 + 40 + 200;
var projectTop = $('.project-article-header').height();
var projectBottom = $(document).height() - $('.footer').height() - $('#nextnav').height() ;
var projectBottom2 = $(document).height() - $('.footer').height() - $('#nextnav').height() - 30;

var stickyNav = function(){
var scrollTop = $(window).scrollTop();
var scrollBottom = $(window).scrollTop() + $(window).height() ;
var PageHeight = $(document).height();
var PageMoreArticles = $('.article-morearticles').height();
var PageFooter = $('.footer').height();



if ($(window).width() > 1300) {
	$('#blockimagecontainer').data('data-tilt',''); //setter
} else {
	
}



if ((scrollTop > topHalf) && (scrollBottom < projectBottom)) { 
    $('.icon-white-btt').addClass('display');
	
}  else {
	 $('.icon-white-btt').removeClass('display');
}



if ($(window).width() > 768) {
	//IF BELOW HEADER
	if (scrollTop > topSpace2) { 
	    $('.desktop-bar').addClass('portfolio-type-on');
	    $('.icon-white').addClass('icon-white-display');
		
	} else { 
		//IF ABOVE HEADER
	    $('.desktop-bar').removeClass('portfolio-type-on');
	     $('.icon-white').removeClass('icon-white-display');
	}
} else {
	//IF BELOW HEADER
	if (scrollTop > topSpace) { 
	    $('.portfolio-type').addClass('portfolio-type-on');
	    $('.icon-white').addClass('icon-white-display');
		
	} else { 
		//IF ABOVE HEADER
	    $('.portfolio-type').removeClass('portfolio-type-on');
	     $('.icon-white').removeClass('icon-white-display');
	}
}





//IF BELOW HEADER
if ((scrollTop > projectTop) && (scrollBottom < projectBottom2) ) { 
    $('.bottom-navigator').addClass('navigator-on');
	
} else { 
	//IF ABOVE HEADER
    $('.bottom-navigator').removeClass('navigator-on');
}


 
};
 
	stickyNav();
 
	$(window).scroll(function() {
	    stickyNav();
	});
});
  

    
	
	

	    
if ($(window).width() <= 1030) {
	   $('#right-button').click(function() {
	  event.preventDefault();
	  $('.home-guide').animate({
	    scrollLeft: "+=480px"
	  }, 'easeOutExpo');
	});
	
	 $('#left-button').click(function() {
	  event.preventDefault();
	  $('.home-guide').animate({
	    scrollLeft: "-=480px"
	  }, 'easeOutExpo');
	});
} else if (($(window).width() > 1030) && ($(window).width() <= 1240)){
	   $('#right-button').click(function() {
	  event.preventDefault();
	  $('.home-guide').animate({
	    scrollLeft: "+=465px"
	  }, 'easeOutExpo');
	});
	
	 $('#left-button').click(function() {
	  event.preventDefault();
	  $('.home-guide').animate({
	    scrollLeft: "-=465px"
	  }, 'easeOutExpo');
	});
} else if ($(window).width() > 1240){
		 $('#right-button').click(function() {
	  event.preventDefault();
	  $('.home-guide').animate({
	    scrollLeft: "+=597px"
	  }, 'easeOutExpo');
	});
	
	 $('#left-button').click(function() {
	  event.preventDefault();
	  $('.home-guide').animate({
	    scrollLeft: "-=597px"
	  }, 'easeOutExpo');
	});
	
	
}	

$(document).ready(function() {
	
	
				
				
    $(".home-guide").on("scroll", function () {
        var cur = $(this).scrollLeft();
        if (cur == 0) {
            $('#left-button').addClass('invisible');
            $('#right-button').removeClass('invisible');
        } 
        else {
            var max = $(this)[0].scrollWidth - $(this).parent().width();
            if (cur == max) {
                $('#right-button').addClass('invisible');
				$('#left-button').removeClass('invisible');
            } else {
                $('#left-button').removeClass('invisible');
				$('#right-button').removeClass('invisible');
            }
        }
    });
    $(".home-guide").trigger("scroll");
});

	 

/**
 * cbpFWTabs.js v1.0.0
 * http://www.codrops.com
 *
 * Licensed under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 * 
 * Copyright 2014, Codrops
 * http://www.codrops.com
 */
;( function( window ) {
	
	'use strict';

	function extend( a, b ) {
		for( var key in b ) { 
			if( b.hasOwnProperty( key ) ) {
				a[key] = b[key];
			}
		}
		return a;
	}

	function CBPFWTabs( el, options ) {
		this.el = el;
		this.options = extend( {}, this.options );
  		extend( this.options, options );
  		this._init();
	}

	CBPFWTabs.prototype.options = {
		start : 0
	};

	CBPFWTabs.prototype._init = function() {
		// tabs elems
		this.tabs = [].slice.call( this.el.querySelectorAll( '.tabs > nav > ul > li' ) );
		
		// content items
		this.items = [].slice.call( this.el.querySelectorAll( '.content-wrap > section' ) );
		// current index
		this.current = -1;
		// show current content item
		this._show();
		// init events
		this._initEvents();
	};

	CBPFWTabs.prototype._initEvents = function() {
		var self = this;
		this.tabs.forEach( function( tab, idx ) {
			tab.addEventListener( 'click', function( ev ) {
				ev.preventDefault();
				self._show( idx );
			} );
		} );
	};

	CBPFWTabs.prototype._show = function( idx ) {
		if( this.current >= 0 ) {
			this.tabs[ this.current ].className = this.items[ this.current ].className = 'tab-not-current'; 
		}
		// change current
		this.current = idx != undefined ? idx : this.options.start >= 0 && this.options.start < this.items.length ? this.options.start : 0;
		this.tabs[ this.current ].className = 'tab-current';
		this.items[ this.current ].className = 'content-current';
	};

	// add to global namespace
	window.CBPFWTabs = CBPFWTabs;

})( window );
   
		      



}); /* end of as page load scripts */
