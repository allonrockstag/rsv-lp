<?php 
	$design = get_post_meta($post->ID, 'wpcf-article-design', true);  
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	?>
              <?php
                /*
                 * This is the default post format.
                 *
                 * So basically this is a regular post. if you don't want to use post formats,
                 * you can just copy ths stuff in here and replace the post format thing in
                 * single.php.
                 *
                 * The other formats are SUPER basic so you can style them as you like.
                 *
                 * Again, If you want to remove post formats, just delete the post-formats
                 * folder and replace the function below with the contents of the "format.php" file.
                */
              ?>
			  
			  	
			  	
				 
              <article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?> role="article">
	              
              	<!--<div itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
				    <div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">
				      <meta itemprop="url" content="https://foxesden.co/wp-content/themes/foxesdentheme/library/images/foxesden-logo-black.png">
				      <meta itemprop="width" content="500">
				      <meta itemprop="height" content="103">
				    </div>
				    <meta itemprop="name" content="Foxesden">
				  </div>
				-->

					
				<div class="m-all t-all d-all cf post-article post-article-project">
				
				
			  	
			  	
		
					 <section class="entry-content cf" itemprop="mainContentOfPage" content="WebPageElement">
	        
	               
                  <?php  the_content(); ?>

                </section> <?php // end article section ?>
                
               
                 	
                 	
                 <div class="m-all t-all d-all cf">
                <footer id="comment" class="article-footer">

                 

                  <?php the_tags( '<p class="tags"><span class="tags-title">' . __( '', 'bonestheme' ) . '</span> ', '', '</p>' ); ?>
                  	
                  	
              

                </footer> <?php // end article footer ?>
			  	</div>
                 
                 </div>
                 

              </article> <?php // end article ?>
              
              
			
			 
			 
		 	