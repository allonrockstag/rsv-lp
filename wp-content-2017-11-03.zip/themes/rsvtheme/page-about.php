<?php
/*
Template Name: About RSV
*/
?>

<?php get_header('white'); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<?php 	
	$about1 = get_post_meta($post->ID, 'wpcf-about-section-1', true);
	$about2 = get_post_meta($post->ID, 'wpcf-about-section-2', true);
	$aboutimg1 = get_post_meta($post->ID, 'wpcf-about-image-1', true);
	$aboutimg2 = get_post_meta($post->ID, 'wpcf-about-image-2', true);
	$aboutimg2 = get_post_meta($post->ID, 'wpcf-about-image-2', true);
	$headervideo = get_post_meta($post->ID, 'wpcf-header-video-bg', true);
	$showreel = get_post_meta($post->ID, 'wpcf-showreel-video-loop', true);
	$placeholder = get_post_meta($post->ID, 'wpcf-showreel-video-placeholder', true);
	$showreelurl = get_post_meta($post->ID, 'wpcf-showreel-video-url', true);
?>

	<?php
		// GET VIMEO ID
		$vimeoUrl = $showreelurl;
	    $fetchVimeoIdArr = explode('/', $vimeoUrl);
	    $idCounter = count($fetchVimeoIdArr) - 1;
	    $vimeoId = $fetchVimeoIdArr[$idCounter];
		
	  ?>
	 
	



<?php endwhile; ?>
<?php else : ?>		
<?php endif; ?>
			
			
			<div id="content" class="contentgrey nopadding">
			<div class="standard-header about-header">
				<?php if(!empty($headervideo)){ ?>
					<video id="headervid" muted loop playsinline preload="auto">
			    <source src="<?php echo $headervideo; ?>" type="video/mp4">
			</video>
					
				<?php } ?>
					
				
				<div id="inner-content" class="wrap wrap-small cf">
					
					<div class="m-all t-all d-all cf">
						<div class="home-title scrollme animateme"
						data-when="span"
					    data-from="1"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="20">
						<h1 class="page-title" itemprop="headline">About <span>RSV</span></h1>
						</div>
					</div>
					
					<main id="main" class="m-all t-all d-all cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

									<?php the_content(); ?>
									
							</article>

							<?php endwhile; ?>
								
							<?php else : ?>

								<?php endif; ?>

						</main>
						
						
				</div>

			</div>
	
				<section class="about" id="1">
					<div id="inner-content" class="wrap cf">
						
							
						<div class="home-1-content scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="-70">
							<div class="about-box left">
								<article>
								<?php echo apply_filters('the_content',$about1); ?>
								</article>
								
							</div>
						</div>
						
						<div class="home-1-content scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="-140">
							<div class="about-image left" style="background-image: url(<?php echo $aboutimg1; ?>);"></div>
						</div>
						
						
					</div>
				</section>
				
				<section class="about" id="2">
					<div id="inner-content" class="wrap cf">
						
							
							
							
							<div class="home-1-content scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="-70">
							
							<div class="about-box right">
								<article>
								<?php echo apply_filters('the_content',$about2); ?>
								</article>
								
							</div>
						</div>
						
						<div class="home-1-content scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="-140">
							<div class="about-image right" style="background-image: url(<?php echo $aboutimg2; ?>);"></div>
							</div>
						
					</div>
				</section>	
					
				
				
				
		         
		         <div class="home-1-content scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="-50">
			<section class="showreel-banner">
				
				<button id="pause-button" class="closevideo"></button>
				
				  <div class="video-overlay">
			            
							
			            <button id="play-button" class="playreel"><i class="fa fa-play" aria-hidden="true"></i>Play Showreel 2017</button>
						
						
			            
		            </div>    	
		                	
				<div class="showreel-video-mobile">
				  <iframe src="https://player.vimeo.com/video/<?php echo $vimeoId; ?>?color=ffffff&title=0&byline=0&portrait=0" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
		         </div>
		         
		         
		         <div id="handstick"><iframe src="https://player.vimeo.com/video/<?php echo $vimeoId; ?>?color=ffffff&title=0&byline=0&portrait=0" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>
									
									<script src="https://player.vimeo.com/api/player.js"></script>
									<script>
										var handstickPlayer = new Vimeo.Player('handstick');
									
										handstickPlayer.ready().then(function() {
										   $('#play-button').click( function() {
											handstickPlayer.setVolume(50);
										   	handstickPlayer.play();
									  		});
									  		
									  		 $('#pause-button').click( function() {
										   	handstickPlayer.pause();
									  		});
										});
											  
										
									</script>
				                 
				                 
				                 
		          
					
					
					
					<video id="vidhero" muted loop playsinline poster="<?php echo $placeholder; ?>" preload="auto">
			    <source src="<?php echo $showreel; ?>" type="video/mp4">
			</video>
			
					
					
				<?php echo apply_filters('the_content',$careerintro); ?>
			</section>	
			
		         </div>
			
			<section class="team">
				<div id="inner-content" class="wrap cf">
					<div class="home-title scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-translatey="-150">
						<h2>Meet<br/>
							The Team
						</h2>
					</div>
					
					<div class="home-1-content scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="-120">
					<ul>
						
						
						<?php 
									
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 50,
									'paged' => $paged,
									'order'=> 'ASC',
									'orderby' => 'date',
									'post_type' => array('team')
									);
									$query = new WP_Query($args);
									?>


							<?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
								$content = get_the_content();
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$jobtitle = get_post_meta($post->ID, 'wpcf-job-title', true);
									 $countpost++;
							?>
							
							
					
									
									<li id="animate<?php echo $countpost;?>">
									<div id="trigger<?php echo $countpost;?>"></div>
									
									  
									<div class="team-image" style="background-image: url(<?php echo $featuredImage;?>)"></div>
								<span>
								<h3><?php the_title(); ?></h3>
									<p><?php echo $jobtitle;?></p>
								
									</span>
							
							
							
							 </li>	
										  
								
							
							<?php endwhile; ?>
							<!-- pagination -->
							
							<?php else : ?>
							<!-- No posts found -->
							<?php endif;
								wp_reset_postdata(); ?>

						
					</ul>
					
					</div>
				</div>
			</section>
			
			<div class="home-1-content scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="-120">
							
			<div class="dot-separator"></div>
			
			</div>
			
			
			<div class="home-1-content scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="-80">
							
							
			<section class="careers-bottom">
				<div id="inner-content" class="wrap wrap-small cf">
					<div class="m-all t-all d-all cf">
							<div class="share-box">
								<h3>Share This</h3>
							<ul class="footer-social">
								<li class="footer-icon"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.linkedin.com/cws/share?url=<?php echo get_permalink(); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							
							</ul>
							</div>
					</div>
				</div>
			</section>
			</div>
				

			</div>


<script>
	
$(".playreel").click(function(){
	    $('#vidhero').addClass('playing');
	    $('.video-overlay').addClass('playing');
	    $('.playreel').addClass('playing');
	    $('.closevideo').addClass('playing');
	    $('.video-player').addClass('playing');
		$('.showreel-banner').addClass('playing');

});

$(".closevideo").click(function(){
    $('#vidhero').removeClass('playing');
	$('.video-overlay').removeClass('playing');
	$('.playreel').removeClass('playing');
	$('.closevideo').removeClass('playing');
	$('.video-player').removeClass('playing');
	$('.showreel-banner').removeClass('playing');
});


	// init controller
	var controller = new ScrollMagic.Controller();


		
	var tween1 = TweenMax.to("#animatelist1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween2 = TweenMax.to("#animatelist2", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween3 = TweenMax.to("#animatelist3", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	
	var headerVid = document.getElementById('headervid');
	var vidHero = document.getElementById('vidhero');
	var $vh = $('#vidhero');

	
	// build scene
				var scene1 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist1",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
					
				var scene2 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist2",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
					
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist3",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);	
					
				var scene4 = new ScrollMagic.Scene({triggerElement: "#triggervid1", duration: 800, offset: 400})
						.setPin("#pin1")
						.addTo(controller);
			
				var scene5 = new ScrollMagic.Scene({triggerElement: "#vidhero", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 vidHero.play();
				
					})
					.on("leave", function () {
							 vidHero.pause();
				
					});
					
			var scene6 = new ScrollMagic.Scene({triggerElement: "#headervid", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 headerVid.play();
				
					})
					.on("leave", function () {
							 headerVid.pause();
				
					});
				
	

	</script>
<?php get_footer(); ?>

