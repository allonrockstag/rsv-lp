<?php if (have_posts()) : while (have_posts()) : the_post();
	$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	
	$company = get_post_meta($post->ID, 'wpcf-brand-company', true);
	$year = get_post_meta($post->ID, 'wpcf-year-of-production', true);
	$time = get_post_meta($post->ID, 'wpcf-lead-time', true);
	$featuredclip = get_post_meta($post->ID, 'wpcf-featured-clip', true);
	$featuredvid = get_post_meta($post->ID, 'wpcf-featured-video', true);
	$vidurl = get_post_meta($post->ID, 'wpcf-video-url', true);
	$logo = get_post_meta($post->ID, 'wpcf-company-logo', true);
	
	$loop = new WP_Query( array( 'post_type' => array('project'), 'posts_per_page' => 3, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) );
	
	?>
	
	
	<?php if($featuredvid == 1) { 
		// GET VIMEO ID
		$vimeoUrl = $vidurl;
	    $fetchVimeoIdArr = explode('/', $vimeoUrl);
	    $idCounter = count($fetchVimeoIdArr) - 1;
	    $vimeoId = $fetchVimeoIdArr[$idCounter];
		
	 }; ?>
	 
	<?php if($featuredvid == 2) { 
		// GET YOUTUBE ID
		$link = $ytid;
		$video_id = explode("?v=", $link); // For videos like http://www.youtube.com/watch?v=...
		if (empty($video_id[1]))
		    $video_id = explode("/v/", $link); // For videos like http://www.youtube.com/watch/v/..
		
		$video_id = explode("&", $video_id[1]); // Deleting any other params
		$video_id = $video_id[0];
	 }; ?>
	

	
		<?php get_header(); ?>		
		
		
		<?php
		$next_post = get_next_post();
		$prev_post = get_previous_post();
		?>
		 
		
							
							
							
		<div class="bottom-navigator">
			
			<?php if (!empty( $prev_post )) {?>
				<a href="<?php echo esc_url( get_permalink( $prev_post->ID ) ); ?>"><button class="nav-next">Next <span><?php echo esc_attr( $prev_post->post_title ); ?></span></button></a>
			
			<?php } else { ?>
					
					<a href="<?php echo home_url(); ?>/portfolio"><button class="nav-portfolio next"><span>Back to Portfolio</span></button></a>
					
			<?php }; ?>
				
			<?php if(!empty( $next_post )) { ?>
				<a href="<?php echo esc_url( get_permalink( $next_post->ID ) ); ?>"><button class="nav-prev">Previous <span><?php echo esc_attr( $next_post->post_title ); ?></span></button></a>
			
			<?php } else { ?>
				<a href="<?php echo home_url(); ?>/portfolio"><button class="nav-portfolio back"><span>Portfolio</span></button></a>
				
			<?php }; ?>
			
			
			
		</div>
		
			<a href="#content"><div class="icon-white-btt"><i class="fa fa-angle-up" aria-hidden="true"></i></div></a>
			
		<div id="content" class="contentgrey nopadding">
			
			<!--<div class="single-videocontainer">
				<div class="single-videooverlay"></div>
			<video id="airpods" poster="<?php bloginfo( 'template_url' ); ?>/library/images/airpod-large.jpg" muted preload="auto" id="bgvid" class="scrollme animateme"
						      data-when="span"
						      data-from="0"
						      data-to="1"
						      data-easing="linear"
						      data-rotatey="0"
						      data-opacity="0.2">
			    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/airpod-large.mp4" type="video/mp4">
			</video>
			</div>
			-->
							
	<?php endwhile; ?>
<?php else : ?>
<?php endif; ?>

				<header class="project-article-header">
			
			
					<div id="inner-content" class="wrap wrap-small cf">	
		
			<?php if($articledesign == 2) { ?>
                <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-scale="0.95"
						data-translatey="-30">
				<?php } else { ?>	
					<div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
							data-scale="0.95"
						data-translatey="20">
				<?php } ?>
		  <ul class="project-cat"><?php
											$term_list = wp_get_post_terms($post->ID, 'project-type');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
													echo '<li><span class="cat"><a href="' . esc_url( $term_link ) . '">' . $term->name . '</a></span></li>';
											
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
								
				

				</ul>
					</div>
				
				<?php if($articledesign == 2) { ?>
                <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-scale="0.95"
						data-translatey="-20">
				<?php } else { ?>	
					<div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
							data-scale="0.95"
						data-translatey="40">
				<?php } ?>	
                  <h1 class="entry-title single-title" itemprop="headline" rel="bookmark"><?php the_title(); ?></h1>
					</div>
					
				<?php if($articledesign == 2) { ?>
                <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-scale="0.95"
						data-translatey="-20">
				<?php } else { ?>	
					<div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
							data-scale="0.95"
						data-translatey="40">
				<?php } ?>
				  <?php if ( has_excerpt() ) { ?>
					    <p class="excerpt" itemprop="description"><?php echo get_the_excerpt(); ?></p>
					<?php } else { ?>
					    
					<?php } ?>
					
					</div>
			
					</div>
					
			
					  <?php echo wp_get_attachment_image( $post->ID , array('700', '600'), "", array( "class" => "img-responsive" ) );  ?>
					
	                <?php if(has_post_thumbnail()) { ?>
	                
	                
	                <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
		                $featuredImageAlt = get_post_meta( get_post_thumbnail_id($post->ID) );
		                $imageAlt = $featuredImageAlt['_wp_attachment_image_alt']['0']; // Display Alt text
		                $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "large" );
 						$image_width = $image_data[1]; 
						$image_height = $image_data[2]; 
	                ?> 	
	                
	              
	              
	          <div class="home-title scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-translatey="-80">
	                <div class="project-featured-img-container">
		                
		               
									
		                <?php if($featuredvid == 1){ ?> <!-- VIMEO  -->
		                	
		                	<div class="project-featured-video-mobile">
				                	<iframe src="https://player.vimeo.com/video/<?php echo $vimeoId; ?>?color=ffffff&title=0&byline=0&portrait=0" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
		                	</div>
							
							
			                 <div class="project-featured-video">
				                 
									<div id="handstick"><iframe src="https://player.vimeo.com/video/<?php echo $vimeoId; ?>?color=ffffff&title=0&byline=0&portrait=0" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>
									
									<script src="https://player.vimeo.com/api/player.js"></script>
									<script>
										var handstickPlayer = new Vimeo.Player('handstick');
									
										handstickPlayer.ready().then(function() {
										   $('#play-button').click( function() {
											handstickPlayer.setVolume(50);
										   	handstickPlayer.play();
									  		});
									  		
									  		 $('#pause-button').click( function() {
										   	handstickPlayer.pause();
									  		});
										});
											  
										
									</script>
				                 
									
				                 <video id="vidhero" muted loop preload="auto">
								    <source src="<?php echo $featuredclip; ?>" type="video/mp4">
								</video>
								
								
							
								<button id="play-button" class="play"><i class="fa fa-play" aria-hidden="true"></i></button>	
								<button id="pause-button" class="closevideo"></button>
							
							<div class="home-title scrollme animateme"
								data-when="enter"
							    data-from="0.5"
							    data-to="0.4"
							    data-easing="linear"
								data-crop="true"
								data-opacity="0"
								data-translatey="40">	
							<div class="video-overlay">
									
								<span class="description">
									<h4>Scope</h4>
									<p><?php echo $company;?></p>
									<h4>Client</h4>
									<p><?php echo $company;?></p>
									<h4>Period</h4>
									<p><?php echo $year;?></p>
									<h4>Lead Time</h4>
									<p><?php echo $time;?></p>
								</span>
								<span class="logo">
									<img src="<?php echo $logo;?>">
								</span>
								
								
							</div>
							</div>
							
								
			                 </div>
			                 
			                 
			            <?php } else if($featuredvid == 2) {  ?> <!-- YOUTUBE  -->
			            		<video id="vidhero" muted loop preload="auto">
								    <source src="<?php echo $featuredclip; ?>" type="video/mp4">
								</video>
								
								
								
		                <?php } else {  ?> <!-- NO VIDEO  -->
			                 <div class="project-featured-img" style="background-image: url(<?php echo $featuredImage; ?>);"></div>
		                <?php } ?>
		              
		               
		              
		               
		                </div>
				      <?php } ?>
	          </div>
				      
                </header> <?php // end article header ?>
                
                
										
						<div id="inner-content" class="wrap wrap-post cf">	
						<main id="main" role="main">
				

							<?php if (have_posts()) : while (have_posts()) : the_post();
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
								$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
								$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
								$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
								$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
								$headertype = get_post_meta($post->ID, 'wpcf-header-type', true);
								$post_type_name = get_post_type( $post->ID );
								$post_type = get_post_type_object( get_post_type($post) );
								$embed_code = wp_oembed_get($vidyoutube);
								$embed_code2 = wp_oembed_get($vidvimeo);
								$titlefonts = get_post_meta($post->ID, 'wpcf-article-title-fonts', true);
								$titlecolor = get_post_meta($post->ID, 'wpcf-article-title-color', true);
								$bgshadow = get_post_meta($post->ID, 'wpcf-background-shadow', true);						
							?>
						 
							
								<?php get_template_part( 'post-formats/format', get_post_format() ); 	?>
							

						<?php endwhile; ?>

						<?php else : ?>

						<?php endif; ?>

						
						
								</main>
								</div>
				<div class="dot-separator"></div>
			<section class="careers-bottom careers-bottom-individual">
				<div id="inner-content" class="wrap wrap-tiny cf">
					<div class="m-all t-all d-all cf">
							<div class="share-box">
								<h3>Share This</h3>
							<ul class="footer-social">
								<li class="footer-icon"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.linkedin.com/cws/share?url=<?php echo get_permalink(); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							
							</ul>
								
							</div>
					</div>
				</div>
			</section>
			
			
			
			
							<?php
							$next_post = get_next_post();
							$prev_post = get_previous_post();
							?>
							 
							<?php if (!empty( $prev_post )) {?>
								<?php 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($prev_post->ID) ); 
								$featuredImageAlt = get_post_meta( get_post_thumbnail_id($prev_post->ID) );
				                $imageAlt = $featuredImageAlt['_wp_attachment_image_alt']['0']; // Display Alt text
				                $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $prev_post->ID ), "large" );
		 						$image_width = $image_data[1]; 
								$image_height = $image_data[2];
								
								$adjpost = $prev_post;
								
								?>
							
							<?php } else if(!empty( $next_post )) { ?>
								<?php 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($next_post->ID) ); 
								$featuredImageAlt = get_post_meta( get_post_thumbnail_id($next_post->ID) );
				                $imageAlt = $featuredImageAlt['_wp_attachment_image_alt']['0']; // Display Alt text
				                $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $next_post->ID ), "large" );
		 						$image_width = $image_data[1]; 
								$image_height = $image_data[2];
								
								$adjpost = $next_post;
								?>
							<?php }; ?>
							
							
							<?php if (!empty( $prev_post )) {?>
							
							<a href="<?php echo esc_url( get_permalink( $adjpost->ID ) ); ?>">
								
								<div class="home-title scrollme animateme"
											data-when="enter"
										     data-from="0.6"
										     data-to="0.3"
										    data-easing="linear"
											data-crop="true"
											data-opacity="0.8"
											data-translatey="80">
												
							<section class="next-case" id="nextnav">
								
								<div class="image" style="background-image: url(<?php echo $featuredImage; ?>)" alt="<?php echo $imageAlt; ?>"><div class="overlay"></div></div>
								
								<div id="inner-content" class="wrap cf">
									<div class="m-all t-all d-all cf">
									 	<div class="home-title scrollme animateme"
											data-when="enter"
										    data-from="0.6"
										    data-to="0.3"
										    data-easing="linear"
											data-crop="true"
											data-opacity="0"
											data-scale="0.95"
											data-translatey="40">	
												
								<h4>Read Next</h4>
							
									 	</div>
									 	
									 	<div class="home-title scrollme animateme"
											data-when="enter"
										     data-from="0.6"
										     data-to="0.3"
										    data-easing="linear"
											data-crop="true"
											data-opacity="0"
											data-scale="0.95"
											data-translatey="60">	
										  <h2>
											   <?php echo esc_attr( $adjpost->post_title ); ?>
											</h2>
									 	</div>
							  
							  		</div>
								</div>
							</section>
								</div>
							</a>
							

							<?php }; ?>
			
			
			
			</div> <!-- end #content -->
			

			<!-- Root element of PhotoSwipe. Must have class pswp. -->
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

    <!-- Background of PhotoSwipe. 
         It's a separate element as animating opacity is faster than rgba(). -->
    <div class="pswp__bg"></div>

    <!-- Slides wrapper with overflow:hidden. -->
    <div class="pswp__scroll-wrap">

        <!-- Container that holds slides. 
            PhotoSwipe keeps only 3 of them in the DOM to save memory.
            Don't modify these 3 pswp__item elements, data is added later on. -->
        <div class="pswp__container">
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
        </div>

        <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
        <div class="pswp__ui pswp__ui--hidden">

            <div class="pswp__top-bar">

                <!--  Controls are self-explanatory. Order can be changed. -->

                <div class="pswp__counter"></div>

                <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>

                <button class="pswp__button pswp__button--share" title="Share"></button>

                <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>

                <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>

                <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
                <!-- element will get class pswp__preloader--active when preloader is running -->
                <div class="pswp__preloader">
                    <div class="pswp__preloader__icn">
                      <div class="pswp__preloader__cut">
                        <div class="pswp__preloader__donut"></div>
                      </div>
                    </div>
                </div>
            </div>

            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                <div class="pswp__share-tooltip"></div> 
            </div>

            <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
            </button>

            <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
            </button>

            <div class="pswp__caption">
                <div class="pswp__caption__center"></div>
            </div>

        </div>

    </div>

</div>


<?php $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "full" ); ?>
<?php $image_width = $image_data[1]; ?>
<?php $image_height = $image_data[2]; ?>
<?php $author = get_the_author(); ?>

<script type="application/ld+json">

{
  "@context": "http://schema.org",
  "@type": "NewsArticle",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "<?php the_ID(); ?>"
  },
  "headline": "<?php the_title(); ?>",
  "image": {
    "@type": "ImageObject",
    "url": "<?php echo $featuredImage; ?>",
    "height": <?php echo $image_height; ?>,
    "width": <?php echo $image_width; ?>
  },
  "datePublished": "<?php the_time('F j, Y'); ?>",
  "dateModified": "<?php the_modified_date('F j, Y'); ?>",
  "author": {
    "@type": "Person",
    "name": "<?php echo $author; ?>"
  },
  "publisher": {
    "@type": "Organization",
    "name": "Foxesden",
    "logo": {
      "@type": "ImageObject",
      "url": "https://foxesden.co/wp-content/themes/foxesdentheme/library/images/foxesden-logo-amp.png",
      "width": 600,
      "height": 60
    }
  },
  "description": "<?php echo get_the_excerpt(); ?>"
}


</script>

<script>
	

	
	
	$(".play").click(function(){
    $('#vidhero').addClass('playing');
    $('.video-overlay').addClass('playing');
    $('.play').addClass('playing');
    $('.closevideo').addClass('playing');
    $('.video-player').addClass('playing');
	$('.project-featured-video').addClass('playing');

});

$(".closevideo").click(function(){
    $('#vidhero').removeClass('playing');
	$('.video-overlay').removeClass('playing');
	$('.play').removeClass('playing');
	$('.closevideo').removeClass('playing');
	$('.video-player').removeClass('playing');
	$('.project-featured-video').removeClass('playing');
});


	var vidHero = document.getElementById('vidhero');
	var airpodVid = document.getElementById('airpods');
	var $lv = $('#airpods');
	
	// init controller
	var controller = new ScrollMagic.Controller();
	
	// build scene
	var scene = new ScrollMagic.Scene({triggerElement: "#airpods", duration: 0 })
					.addTo(controller)
					.addIndicators() // add indicators (requires plugin)
										
					.on("enter", function () {
						if(!$lv.hasClass('hasplayed')){
							 airpodVid.play();
							 $lv.addClass('hasplayed');
						} else {
							
						}
						
					});
					
				//.on("leave", function () {
				//		airpodVid.pause();
				//	 })
	var scene2 = new ScrollMagic.Scene({triggerElement: "#vidhero", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 vidHero.play();
				
					});
				
</script>



<?php get_footer(); ?>


