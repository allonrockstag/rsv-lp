<?php if (have_posts()) : while (have_posts()) : the_post();
	$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	
	$headertype = get_post_meta($post->ID, 'wpcf-header-type', true);
	$titlefonts = get_post_meta($post->ID, 'wpcf-article-title-fonts', true);
	$titlecolor = get_post_meta($post->ID, 'wpcf-article-title-color', true);
	$bgshadow = get_post_meta($post->ID, 'wpcf-background-shadow', true);
	
	$loop = new WP_Query( array( 'post_type' => array('project'), 'posts_per_page' => 3, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) );
	
	?>

	
			<?php get_header(); ?>					
			<div id="content" class="contentgrey nopadding">
	
		 
							
	<?php endwhile; ?>
<?php else : ?>
<?php endif; ?>

			
	            	<?php if (have_posts()) : while (have_posts()) : the_post();
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
								$jobtype = get_post_meta($post->ID, 'wpcf-job-type', true);
								$location = get_post_meta($post->ID, 'wpcf-position-location', true);
								$status = get_post_meta($post->ID, 'wpcf-position-status', true);					
							?>
				 <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="0.5"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.5"
						data-translatey="-20">	
				<header class="career-header">
					<div id="inner-content" class="wrap wrap-tiny cf">	
						
						
					<p class="byline entry-meta vcard"> </p>
                  <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-translatey="-40">	
							
                  <h3><a href="<?php echo home_url(); ?>/careers">Careers At RSV</a></h3>
                  </div>
                  <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-translatey="-30">		
							
                  <h1 class="entry-title single-title" itemprop="headline" rel="bookmark"><?php the_title(); ?></h1>
                  </div>
                  
                   <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-translatey="-20">	
							
							
                  <p>
									<?php if($jobtype == 1){ ?>
										<span class="ft">Full Time</span>
									<?php } else if ($jobtype == 2){ ?>
										<span class="pt">Part Time</span>
									<?php } else if ($jobtype == 3){ ?>
										<span class="intern">Internship</span>
									<?php } else if ($jobtype == 4){ ?>
										<span class="contract">Contract</span>
									<?php } ?>
									
									<?php if($location == 1){ ?>
										<span class="location">Singapore</span>
									<?php } else if ($location == 2){ ?>
										<span class="location">Melbourne</span>
									<?php } else if ($location == 3){ ?>
										<span class="location">New Zealand</span>
									<?php } ?>
									</p>
									
                  
									
						<button class="apply"><a href="#apply"><span>Apply for Position</span></a></button>		
						 </div>	
					</div>
                </header> <?php // end article header ?>
				
				 </div>			
						<div id="inner-content" class="wrap wrap-tiny cf">	
						<main id="main" role="main">
				

							
							
								<?php get_template_part( 'post-design/format-career', get_post_format() ); 	?>
							

							
							<div class="post-bottom-bar">
								<ul class="post-share-mobile">
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
					  	<li class="share-pinterest"><a href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo $featuredImage; ?>&description=<?php the_title();?>" target="_blank"><span></span></a></li>
<li class="share-comment"><a href="#comment"><span>Comments</span></a></li>


				  	</ul>
							</div>

						
						
								</main>
						
						</div>
				
								
								
						
						<?php endwhile; ?>

						<?php else : ?>

						<?php endif; ?>

					
						
				<section class="careers-bottom careers-bottom-individual">
				<div id="inner-content" class="wrap wrap-tiny cf">
					<div class="m-all t-all d-all cf">
							<div class="share-box">
								<h3>Share This</h3>
							<ul class="footer-social">
								<li class="footer-icon"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.linkedin.com/cws/share?url=<?php echo get_permalink(); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							
							</ul>
								
							</div>
					</div>
				</div>
			</section>
			
			</div> <!-- end #content -->
			



<?php $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "full" ); ?>
<?php $image_width = $image_data[1]; ?>
<?php $image_height = $image_data[2]; ?>
<?php $author = get_the_author(); ?>

<script type="application/ld+json">

{
  "@context": "http://schema.org",
  "@type": "NewsArticle",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "<?php the_ID(); ?>"
  },
  "headline": "<?php the_title(); ?>",
  "image": {
    "@type": "ImageObject",
    "url": "<?php echo $featuredImage; ?>",
    "height": <?php echo $image_height; ?>,
    "width": <?php echo $image_width; ?>
  },
  "datePublished": "<?php the_time('F j, Y'); ?>",
  "dateModified": "<?php the_modified_date('F j, Y'); ?>",
  "author": {
    "@type": "Person",
    "name": "<?php echo $author; ?>"
  },
  "publisher": {
    "@type": "Organization",
    "name": "Foxesden",
    "logo": {
      "@type": "ImageObject",
      "url": "https://foxesden.co/wp-content/themes/foxesdentheme/library/images/foxesden-logo-amp.png",
      "width": 600,
      "height": 60
    }
  },
  "description": "<?php echo get_the_excerpt(); ?>"
}


</script>

<script>
	
	
	var airpodVid = document.getElementById('airpods');
	var $lv = $('#airpods');

	// init controller
	var controller = new ScrollMagic.Controller();
	
	// build scene
	var scene = new ScrollMagic.Scene({triggerElement: "#airpods", duration: 0 })
					.addTo(controller)
					.addIndicators() // add indicators (requires plugin)
										
					.on("enter", function () {
						if(!$lv.hasClass('hasplayed')){
							 airpodVid.play();
							 $lv.addClass('hasplayed');
						} else {
							
						}
						
					})
					
				//.on("leave", function () {
				//		airpodVid.pause();
				//	 })
				
</script>



<?php get_footer(); ?>


