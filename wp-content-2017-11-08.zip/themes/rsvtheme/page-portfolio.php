<?php
/*
 Template Name: Portfolio
*/
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>



	<?php get_header(); ?>

	<?php 
		global $post;
		$pageslug=$post->post_name;
	?>

 <?php endwhile; ?>
								
<?php else : ?>

<?php endif; ?>
							
<?php 
	
	if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
					elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
					else { $paged = 1; }
	?>
					
			
				<div class="portfolio-type desktop desktop-bar">
					<a href="#content"><div class="icon-white"><i class="fa fa-angle-up" aria-hidden="true"></i></div></a>
					
					<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => '',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'Portfolio' ,  // nav name
    					         'menu_class' => ''              // adding custom nav class
						)); ?>
				
					</div>
					
					
					
		
				<div id="content" class="contentgrey">
				
				
					
				<div class="standard-header work-header">
				<div id="inner-content" class="wrap wrap-small cf">
					<div class="m-all t-all d-all cf">
						<div class="home-title scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-scale="0.95"
						data-translatey="50">
							
							<?php	if($pageslug == 'commercials'){
								$pagelabel = 'Commercials';
							} else if($pageslug == 'music-video-production') {
								$pagelabel = 'Music Videos';
							} else if($pageslug == 'corporate-videos') {
								$pagelabel = 'Corporate Videos';
							} else if($pageslug == 'short-film-production') {
								$pagelabel = 'Short Films';
							} else if($pageslug == 'portfolio') {
								$pagelabel = 'Work';
							} ?>
							
							
						<h1 class="page-title" itemprop="headline">Our <span><?php echo $pagelabel;?></span></h1>
						</div>
					</div>
				</div>
			</div>
			
				
				<script>
			// init controller
			var controller = new ScrollMagic.Controller();
		</script>
		
				
				<section class="portfolio-1">
					
					
					
					<div class="portfolio-type mobile">
					
					
					<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => '',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'Portfolio' ,  // nav name
    					         'menu_class' => ''              // adding custom nav class
						)); ?>
				
						</div>
				
				
				
					<div class="portfolio-type desktop">
					
					<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => '',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'Portfolio' ,  // nav name
    					         'menu_class' => ''              // adding custom nav class
						)); ?>
				
					</div>
					
					<div id="inner-content" class="wrap wrap-home-wide superwide cf">
						<div id="trigger1"></div>
						<div class="m-all t-all d-all cf">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
				
				
				
					
					
						<div class="home-title scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-translatey="-30">
							
							
								<div class="portfolio-description"><?php the_content(); ?></div>
								</div>
						
						
						<ul class="portfolio-list">
								
					<?php	if($pageslug == 'commercials'){
								$term_slug = array('commercials');
							} else if($pageslug == 'music-video-production') {
								$term_slug = array('music-video');
							} else if($pageslug == 'corporate-videos') {
								$term_slug = array('corporate-videos');
							} else if($pageslug == 'short-film-production') {
								$term_slug = array('short-film');
							} else if($pageslug == 'portfolio') {
								$term_slug = array('portfolio');
							} ?>
						
									<?php $sticky_posts = get_option( 'sticky_posts' );?>
									
									<?php if ($pageslug == 'portfolio') {
										$args = array(
										'posts_per_page' => 9,
										'paged' => $paged,
										'order'=> 'DESC',
										'orderby' => 'date',
										'post_type' => array('project')
										);
									} else {
										$args = array(
										'posts_per_page' => 9,
										'paged' => $paged,
										'order'=> 'DESC',
										'orderby' => 'date',
										'post_type' => array('project'),
										'tax_query' => array(
						                    array(
						                        'taxonomy' => 'project-type',
						                        'field'    => 'slug',
						                        'terms'    => $term_slug,
						                    ),
						                )
										);
									}
									
									
									
									$query = new WP_Query($args);
									$countpost = 1;
									?>

									
							<?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
								$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'medium', false, '' );
									$largeimgsrc = $largeimg[0]; 
									$brand = get_post_meta($post->ID, 'wpcf-brand-company', true);
									$year = get_post_meta($post->ID, 'wpcf-year-of-production', true);
									$leadtime = get_post_meta($post->ID, 'wpcf-lead-time', true);
									$featuredclip = get_post_meta($post->ID, 'wpcf-featured-clip', true);
									$featuredvid = get_post_meta($post->ID, 'wpcf-featured-video', true);
									$vidurl = get_post_meta($post->ID, 'wpcf-video-url', true);
									$logo = get_post_meta($post->ID, 'wpcf-company-logo', true);
									 $countpost++;
							?>
							
							
					
									
									<li id="animate<?php echo $countpost;?>"><div id="trigger<?php echo $countpost;?>"></div>
									  
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
								 
								 
							<!--	 <div id="blockimagecontainer" data-tilt data-tilt-glare="true" data-tilt-maxglare=".2" data-tilt-perspective="500" data-tilt-speed="1500" data-tilt-scale="1.02" data-tilt-max="3"> -->
									 
									 <div class="home-title scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-translatey="-80">
								<div id="blockimagecontainer">
								
									<div class="overlay">
										
									
									
										<h2 class="entry-title"><?php the_title(); ?></h2>
									

								
									<?php if ( ! has_excerpt() ) { ?>
										 <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<? } else {  ?>
										     
										<?php } ?>
										
										<?php if (!empty($brand)) { ?>
										 <p><?php echo $brand; ?></p>
										<?php } ?>
										
								
										<span class="read"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i><p>Read</p></span>
									</div>
								<?php if((!empty ($featuredclip))&& ($countpost <= 4)){ ?>
									<div id="blockimage" class="video" style="background-image: url('<?php echo $featuredImage; ?>');">
										<video id="vidhero<?php echo $countpost;?>" muted loop preload="auto">
								    <source src="<?php echo $featuredclip; ?>" type="video/mp4">
								</video>
								
									</div>
								<?php } else { ?>
								<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div>
								<?php } ?>
								
								
								</div>
								
									 </div>
								</a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					       
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								
									<?php if ( ! has_excerpt() ) { ?>
										 <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<? } else {  ?>
										     
										<?php } ?>
										
										<?php if (!empty($brand)) { ?>
										 <p><?php echo $brand; ?></p>
										<?php } ?>
								
								
							</article></a>
							
							
										  </li>	
							
							<?php endwhile; ?>
							<!-- pagination -->
							
							<?php else : ?>
							<!-- No posts found -->
							<?php endif;
								wp_reset_postdata(); ?>
								
								
									
								</ul>	
						
						
						
				
				

			<?php endwhile; ?>
				
			<?php else : ?>

			<?php endif; ?>
			
						</div>
					</div>
				</section>
						
						
				<section class="portfolio-clients">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
						
							<h2>Clients & Partners</h2>
								<ul>
									
										<?php 
									
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 30,
									'paged' => $paged,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('client')
									);
									$query = new WP_Query($args);
									?>


							<?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
								$content = get_the_content();
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$company = get_post_meta($post->ID, 'wpcf-brand-company', true);
									$year = get_post_meta($post->ID, 'wpcf-year-of-project', true);
									$time = get_post_meta($post->ID, 'wpcf-lead-time', true);
									 $countpost++;
							?>
							
							
					
									
									<li id="animate<?php echo $countpost;?>">
							          
									
									<p class="entry-title"><?php the_title(); ?></p>
									
									<span><?php echo $year;?></span>
							
							
							
							 </li>	
										  
								
							
							<?php endwhile; ?>
							<!-- pagination -->
							
							<?php else : ?>
							<!-- No posts found -->
							<?php endif;
								wp_reset_postdata(); ?>

							</ul>
							
							<ul>

							<?php 
								
								$images = get_post_meta($post->ID, 'wpcf-client-logos');
									foreach ($images as $img) { ?>
									
								
							
									<li class="home-logos scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.7"
						data-translatey="60"><img src="<?php echo $img;?>"></li>
									<?php } ?>
									
							</ul>
							
						</div>
							
					</div>
				</section>
				
				
				
					
				</div>

	
		<script>
			 	
				
	

	

				
					

				// https://greensock.com/docs/Easing/Circ
				var vidHero1 = document.getElementById('vidhero1');
				var vidHero2 = document.getElementById('vidhero2');
				var vidHero3 = document.getElementById('vidhero3');
				var vidHero4 = document.getElementById('vidhero4');
				var tween1 = TweenMax.to("#animate1", 1.4, {className: "+=isvisible", reverse:false, delay: 0.7, ease: Expo.easeOut});
				var tween2 = TweenMax.to("#animate2", 1.4, {className: "+=isvisible", reverse:false, delay: 0.8, ease: Expo.easeOut});
				var tween3 = TweenMax.to("#animate3", 1.4, {className: "+=isvisible", reverse:false, delay: 0.9, ease: Expo.easeOut});
				var tween4 = TweenMax.to("#animate4", 1.4, {className: "+=isvisible", reverse:false, delay: 0.2, ease: Expo.easeOut});		
				var tween5 = TweenMax.to("#animate5", 1.4, {className: "+=isvisible", reverse:false, delay: 0.3, ease: Expo.easeOut});	
				var tween6 = TweenMax.to("#animate6", 1.4, {className: "+=isvisible", reverse:false, delay: 0.2, ease: Expo.easeOut});	
				var tween7 = TweenMax.to("#animate7", 1.4, {className: "+=isvisible", reverse:false, delay: 0.3, ease: Expo.easeOut});	
				var tween8 = TweenMax.to("#animate8", 1.4, {className: "+=isvisible", reverse:false, delay: 0.2, ease: Expo.easeOut});	
				var tween9 = TweenMax.to("#animate9", 1.4, {className: "+=isvisible", reverse:false, delay: 0.3, ease: Expo.easeOut});	
				var tween10 = TweenMax.to("#animate10", 1.4, {className: "+=isvisible", reverse:false, delay: 0.2, ease: Expo.easeOut});
				var tween11 = TweenMax.to("#animate11", 1.4, {className: "+=isvisible", reverse:false, delay: 0.3, ease: Expo.easeOut});	
				var tween12 = TweenMax.to("#animate12", 1.4, {className: "+=isvisible", reverse:false, delay: 0.2, ease: Expo.easeOut});
				var tween13 = TweenMax.to("#animate13", 1.4, {className: "+=isvisible", reverse:false, delay: 0.3, ease: Expo.easeOut});				
				// build scene
				var scene = new ScrollMagic.Scene({
					triggerElement: "#trigger1",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
				var scene2 = new ScrollMagic.Scene({
					triggerElement: "#trigger1",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#trigger1",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);
				var scene4 = new ScrollMagic.Scene({
					triggerElement: "#trigger4",
					reverse: false,
					duration: 0
					})
					.setTween(tween4)
					.addTo(controller);
				var scene5 = new ScrollMagic.Scene({
					triggerElement: "#trigger5",
					reverse: false,
					duration: 0
					})
					.setTween(tween5)
					.addTo(controller);
				var scene6 = new ScrollMagic.Scene({
					triggerElement: "#trigger6",
					reverse: false,
					duration: 0
					})
					.setTween(tween6)
					.addTo(controller);
				var scene7 = new ScrollMagic.Scene({
					triggerElement: "#trigger7",
					reverse: false,
					duration: 0
					})
					.setTween(tween7)
					.addTo(controller);
				var scene8 = new ScrollMagic.Scene({
					triggerElement: "#trigger8",
					reverse: false,
					duration: 0
					})
					.setTween(tween8)
					.addTo(controller);
				var scene9 = new ScrollMagic.Scene({
					triggerElement: "#trigger9",
					reverse: false,
					duration: 0
					})
					.setTween(tween9)
					.addTo(controller);
				var scene10 = new ScrollMagic.Scene({
					triggerElement: "#trigger10",
					reverse: false,
					duration: 0
					})
					.setTween(tween10)
					.addTo(controller);
				var scene11 = new ScrollMagic.Scene({
					triggerElement: "#trigger11",
					reverse: false,
					duration: 0
					})
					.setTween(tween11)
					.addTo(controller);
				var scene12 = new ScrollMagic.Scene({
					triggerElement: "#trigger12",
					reverse: false,
					duration: 0
					})
					.setTween(tween12)
					.addTo(controller);
					
				var scene51 = new ScrollMagic.Scene({triggerElement: "#vidhero1", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 vidHero1.play();
				
					})
					.on("leave", function () {
							 vidHero1.pause();
				
					});
				var scene52 = new ScrollMagic.Scene({triggerElement: "#vidhero2", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 vidHero2.play();
				
					})
					.on("leave", function () {
							 vidHero2.pause();
				
					});
				var scene53 = new ScrollMagic.Scene({triggerElement: "#vidhero3", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 vidHero3.play();
				
					})
					.on("leave", function () {
							 vidHero3.pause();
				
					});
				var scene54 = new ScrollMagic.Scene({triggerElement: "#vidhero4", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 vidHero4.play();
				
					})
					.on("leave", function () {
							 vidHero4.pause();
				
					});
		</script>



<?php get_footer(); ?>
