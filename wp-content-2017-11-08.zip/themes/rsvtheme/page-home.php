<?php
/*
 Template Name: Home
*/
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<?php 	$slides = get_post_meta($post->ID, 'wpcf-number-of-slides', true);
		$cell1title = get_post_meta($post->ID, 'wpcf-slide-1-title', true);
		$cell2title = get_post_meta($post->ID, 'wpcf-slide-2-title', true); 
		$cell3title = get_post_meta($post->ID, 'wpcf-slide-3-title', true);
		$cell1text = get_post_meta($post->ID, 'wpcf-slide-1-description', true); 
		$cell2text = get_post_meta($post->ID, 'wpcf-slide-2-description', true);
		$cell3text = get_post_meta($post->ID, 'wpcf-slide-3-description', true);
		$cell1image = get_post_meta($post->ID, 'wpcf-slide-1-background', true);
		$cell2image = get_post_meta($post->ID, 'wpcf-slide-2-background', true);
		$cell3image = get_post_meta($post->ID, 'wpcf-slide-3-background', true);
		$cell1vidbg = get_post_meta($post->ID, 'wpcf-slide-1-video-background', true);
		$cell2vidbg = get_post_meta($post->ID, 'wpcf-slide-2-video-background', true);
		$cell3vidbg = get_post_meta($post->ID, 'wpcf-slide-3-video-background', true);
		$cell1vid = get_post_meta($post->ID, 'wpcf-slide-1-video-loop', true);
		$cell2vid = get_post_meta($post->ID, 'wpcf-slide-2-video-loop', true);
		$cell3vid = get_post_meta($post->ID, 'wpcf-slide-3-video-loop', true);
		$cell1link = get_post_meta($post->ID, 'wpcf-slide-1-link', true);
		$cell2link = get_post_meta($post->ID, 'wpcf-slide-2-link', true);
		$cell3link = get_post_meta($post->ID, 'wpcf-slide-3-link', true);
		$svc1 = get_post_meta($post->ID, 'wpcf-service-1', true);
		$svc2 = get_post_meta($post->ID, 'wpcf-service-2', true);
		$svc3 = get_post_meta($post->ID, 'wpcf-service-3', true);
		$svc4 = get_post_meta($post->ID, 'wpcf-service-4', true);
		$svc5 = get_post_meta($post->ID, 'wpcf-service-5', true);
		$svc6 = get_post_meta($post->ID, 'wpcf-service-6', true);
		$highlight1 = get_post_meta($post->ID, 'wpcf-highlight-1', true);
		$highlight2 = get_post_meta($post->ID, 'wpcf-highlight-2', true);
		$showreel = get_post_meta($post->ID, 'wpcf-showreel-video-loop', true);
	$placeholder = get_post_meta($post->ID, 'wpcf-showreel-video-placeholder', true);
	$showreelurl = get_post_meta($post->ID, 'wpcf-showreel-video-url', true);
?>

<?php
		// GET VIMEO ID
		$vimeoUrl = $showreelurl;
	    $fetchVimeoIdArr = explode('/', $vimeoUrl);
	    $idCounter = count($fetchVimeoIdArr) - 1;
	    $vimeoId = $fetchVimeoIdArr[$idCounter];
		
	  ?>


	<?php get_header('white'); ?>


 <?php endwhile; ?>
								
<?php else : ?>

<?php endif; ?>
							
<?php 
	
	if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
					elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
					else { $paged = 1; }
	?>
					
					
		
				<div id="content" class="nopadding">
				<section class="home-top">
					<div class="home-top-container scrollme animateme"
						      data-when="exit"
						      data-from="0"
						      data-to="1"
						      data-easing="linear"
						      data-rotatey="0"
							 data-opacity="0.2">
							 
						   <?php if($slides > 1){ ?>
						   <?php } else { ?>
							   	<a href="#intro"><span class="down"><i class="fa fa-long-arrow-down" aria-hidden="true"></i></span></a>
					 		<?php } ?>
						
						
						<div class="main-top-icons">
							
							<?php if($slides > 1){ ?>
						<ul class="footer-social">
	
						<?php } else { ?>
						<ul class="footer-social" id="singleslide"> 
	
						<?php } ?>
						
						
								<li class="footer-icon"><a href="https://www.facebook.com/foxesden.co/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<!--<li class="footer-icon"><a href="https://twitter.com/foxesden?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>-->
								<li class="footer-icon"><a href="https://www.youtube.com/channel/UCdjmRNHp3aOm4_zhOrNxhPg"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.instagram.com/foxesden.co/"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							</ul>
							
							
							</div>
							
							
						<?php if($slides > 1){ ?>
						<div class="main-carousel" data-flickity='{ "cellAlign": "left", "autoPlay": 7000, "wrapAround": true, "contain": true, "selectedAttraction": 0.02,
"friction": 0.4, "pauseAutoPlayOnHover": false, "dragThreshold": 15}'>		
	
						<?php } else { ?>
						<div class="main-carousel" data-flickity='{ "cellAlign": "left", "autoPlay": false, "wrapAround": true, "contain": true, "selectedAttraction": 0.02,
"friction": 0.4, "pauseAutoPlayOnHover": false, "pageDots": false, "prevNextButtons": false, "draggable": false, "dragThreshold": 15}'>	
	
						<?php } ?>
						
						
						<?php if($slides >= 1){ ?>
						
								<?php if($cell1vidbg == 1){ ?>
								<div class="carousel-cell carousel-cell-1" style="background-image:url(<?php echo $cell1image; ?>);">
								<?php } else  { ?>
								<div class="carousel-cell carousel-cell-1" style="background-image:url('../images/menu-bg.jpg');">		
								<?php } ?>
						
								
								 <?php if($cell1vidbg == 1){ ?>
						
								
								 <?php } else if($cell1vidbg == 2) { ?>
									<video class="videotop" id="vidtop"  muted loop playsinline autoplay="autoplay" preload="auto">
									    <source src="<?php echo $cell1vid; ?>" type="video/mp4">
									</video>
									
									
								<?php } else  { ?>
										
								<?php } ?>
						
							  <div class="carousel-overlay"></div>
							  
							 
								
								
							<div class="home-title scrollme animateme"
						      data-when="exit"
						      data-from="0"
						      data-to="1"
						      data-easing="linear"
								 data-translatey="120">
							  <div class="carousel-text">
							  
							  <h2><?php echo $cell1title; ?></h2>
							  <p><?php echo $cell1text; ?></p>
							  
							  <?php if($slides > 1){ ?>
					 <a href="<?php echo $cell1link; ?>"><span class="read"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i><p>Read</p></span></a>
	
						<?php } else { ?>
						 <a href="<?php echo $cell1link; ?>"><span class="read reel"><p>Watch Our Reel</p></span></a>
						 <a href="<?php echo home_url(); ?>/portfolio"><span class="read reel"><p>Our Work</p></span></a>
						<?php } ?>
						
						
							  </div>
							</div>
						  </div>
						<?php } ?>
						  
						  <?php if($slides >= 2){ ?>
							<div class="carousel-cell carousel-cell-2" style="background-image:url(<?php echo $cell2image; ?>);">
							  <div class="carousel-overlay"></div>
							  
							  <div class="home-title scrollme animateme"
						      data-when="exit"
						      data-from="0"
						      data-to="1"
						      data-easing="linear"
						      data-rotatey="0"
								 data-translatey="120">
							  <div class="carousel-text">
						
							  <h2><?php echo $cell2title; ?></h2>
							  <p><?php echo $cell2text; ?></p>
							  <a href="<?php echo $cell2link; ?>"><span class="read"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i><p>Read</p></span></a>
							  
							  </div>
							  </div>
						  </div>
						<?php } ?>
						
						 
						  <?php if($slides >= 3){ ?>
							<div class="carousel-cell carousel-cell-3" style="background-image:url(<?php echo $cell3image; ?>);">
							  <div class="carousel-overlay"></div>
							  
							  <div class="home-title scrollme animateme"
						      data-when="exit"
						      data-from="0"
						      data-to="1"
						      data-easing="linear"
						      data-rotatey="0"
								 data-translatey="120">
							  <div class="carousel-text">
						
							  <h2><?php echo $cell3title; ?></h2>
							  <p><?php echo $cell3text; ?></p>
							  <a href="<?php echo $cell3link; ?>"><span class="read"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i><p>Read</p></span></a>
							  </div>
							  </div>
						  </div>
						<?php } ?>
						
						</div>

					</div>
				</section>
				
				<section class="home-1" id="intro">
					
					<div 
						class="home-bgarrow1 scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
					    data-translatex="300"
						data-crop="true"
						data-opacity="0"
					></div>
					
					<div 
						class="home-bgarrow2 scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
					    data-translatex="500"
						data-crop="true"
						data-opacity="0"
					></div>
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-3of4 cf">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
				<div class="home-title scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-translatey="50">
							
				<h1>Rockstagvid Productions</h1>
				</div>
				
				
				<div class="home-1-content scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-translatey="90"
						>
						<?php the_content(); ?>
					</div>
				
				
				

			<?php endwhile; ?>
				
			<?php else : ?>

			<?php endif; ?>
			
						</div>
					</div>
					
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
							<div id="triggerlist"></div>
						<ul class="home-svc-list">
							<li id="animatelist1"><?php echo apply_filters('the_content',$svc1); ?></li>
							<li id="animatelist2"><?php echo apply_filters('the_content',$svc2); ?></li>
							<li id="animatelist3"><?php echo apply_filters('the_content',$svc3); ?></li>
							<li id="animatelist4"><?php echo apply_filters('the_content',$svc4); ?></li>
							<li id="animatelist5"><?php echo apply_filters('the_content',$svc5); ?></li>	
						</ul>
						<div class="home-links">
						<p class="standard-button home-1-button" id="animatelistlink1"><a href="<?php echo home_url(); ?>/portfolio">Our Portfolio</a></p>
						<p class="standard-button home-1-button" id="animatelistlink2"><a href="<?php echo home_url(); ?>/services">Get a Quote</a></p>
						</div>
						</div>
					</div>
					
				<section class="showreel-banner home-showreel">
					<div id="triggerreel"></div>
					<button id="pause-button" class="closevideo"></button>
				
				  <div class="video-overlay">
			            
							
			            <button id="play-button" class="playreel"><i class="fa fa-play" aria-hidden="true"></i>Play Showreel 2017</button>
						
						
			            
		            </div>    	
		                	
				<div class="showreel-video-mobile">
				  <iframe src="https://player.vimeo.com/video/<?php echo $vimeoId; ?>?color=ffffff&title=0&byline=0&portrait=0" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
		         </div>
		         
		         
		         <div id="handstick"><iframe src="https://player.vimeo.com/video/<?php echo $vimeoId; ?>?color=ffffff&title=0&byline=0&portrait=0" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>
									
									<script src="https://player.vimeo.com/api/player.js"></script>
									<script>
										var handstickPlayer = new Vimeo.Player('handstick');
									
										handstickPlayer.ready().then(function() {
										   $('#play-button').click( function() {
											handstickPlayer.setVolume(50);
										   	handstickPlayer.play();
									  		});
									  		
									  		 $('#pause-button').click( function() {
										   	handstickPlayer.pause();
									  		});
										});
											  
										
									</script>
				                 
				                 
				                 
		          
					
					
					
					<video id="reel" muted loop playsinline preload="auto">
			    <source src="<?php echo $showreel; ?>" type="video/mp4">
			</video>
			
					
					
				<?php echo apply_filters('the_content',$careerintro); ?>
			</section>	
			
			
				
					<!--	<div id="inner-content" class="wrap wrap-home-wide superwide home-highlight-1 cf">
						<ul class="portfolio-list portfolio-list-home">
							
							
							<?php 
									
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 1,
									'paged' => $paged,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('project')
									);
									$query = new WP_Query($args);
									?>


							<?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
								$content = get_the_content();
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$brand = get_post_meta($post->ID, 'wpcf-brand-company', true);
									$year = get_post_meta($post->ID, 'wpcf-year-of-production', true);
									$leadtime = get_post_meta($post->ID, 'wpcf-lead-time', true);
									$featuredclip = get_post_meta($post->ID, 'wpcf-featured-clip', true);
									$featuredvid = get_post_meta($post->ID, 'wpcf-featured-video', true);
									$vidurl = get_post_meta($post->ID, 'wpcf-video-url', true);
									$logo = get_post_meta($post->ID, 'wpcf-company-logo', true);
									 $countpost++;
							?>
							
								
								
									
								<li>
									  
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
								 
								<div id="blockimagecontainer">
								
									<div class="overlay">
										
									
									
										<h2 class="entry-title"><?php the_title(); ?></h2>
									

								
									<?php if ( ! has_excerpt() ) { ?>
										 <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<? } else {  ?>
										     
										<?php } ?>
										
										<?php if (!empty($brand)) { ?>
										 <p><?php echo $brand; ?></p>
										<?php } ?>
										
								
										<span class="read"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i><p>Read</p></span>
									</div>
								<?php if((!empty ($featuredclip))&& ($countpost <= 4)){ ?>
									<div id="blockimage" class="video" style="background-image: url('<?php echo $featuredImage; ?>');">
										<video id="vidhero<?php echo $countpost;?>" muted loop preload="auto">
								    <source src="<?php echo $featuredclip; ?>" type="video/mp4">
								</video>
								
									</div>
								<?php } else { ?>
								<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div>
								<?php } ?>
								
								
								</div>
								
								</a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					       
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								
									<?php if ( ! has_excerpt() ) { ?>
										 <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<? } else {  ?>
										     
										<?php } ?>
										
										<?php if (!empty($brand)) { ?>
										 <p><?php echo $brand; ?></p>
										<?php } ?>
								
								
							</article></a>
							
							
										  </li>	
							
							<?php endwhile; ?>
							
							<?php else : ?>
							<?php endif;
								wp_reset_postdata(); ?>
								
								
							
						</ul>
						</div> -->
						
				</section>
				
				<section class="home-2">
					<div class="home-2-container">
						<h2>Blog</h2>
						<div id="trigger<?php echo $countpost;?>"></div>
						
					
						
					<div class="home-blog-carousel" data-flickity='{ "cellAlign": "left", "contain": true, "autoPlay": false, "wrapAround": false, "selectedAttraction": 0.07, "friction": 0.7, "adaptiveHeight": true, "pauseAutoPlayOnHover": true, "dragThreshold": 15, "prevNextButtons": true, "pageDots": false, "groupCells": "100%"}'>
						
							<?php 
									
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 4,
									'paged' => $paged,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('post')
									);
									$query = new WP_Query($args);
									?>


							<?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
								$content = get_the_content();
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$jobtype = get_post_meta($post->ID, 'wpcf-job-type', true);
									$location = get_post_meta($post->ID, 'wpcf-position-location', true);
									$status = get_post_meta($post->ID, 'wpcf-position-status', true);
									 $countpost++;
							?>
							
									
									
							<div class="carousel-cell carousel-cell-<?php echo $countpost;?>">
							  <div class="list-item">
								<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
								<div id="blockimage" style="background-image: url(<?php echo $featuredImage;?>);"></div></a>
								<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
								<span>
									<h2><?php the_title(); ?></h2>
									<?php if ( has_excerpt() ) { ?>
									    <p><?php echo get_the_excerpt(); ?></p>
									<?php } else { ?>
									    
									<?php } ?>
								</span>
								</a>
							</div>
						  </div>
								
							
							<?php endwhile; ?>
							<!-- pagination -->
							
							<?php else : ?>
							<!-- No posts found -->
							<?php endif;
								wp_reset_postdata(); ?>
								

						
					</div>
					<h4><a href="<?php echo home_url(); ?>/blog">More from our Blog</a></h4>
					</div>
				</section>				
						
				<section class="home-3">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
							<div class="home-title scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-translatey="30">
							<h2>Clients & Partners</h2>
							</div>
								<ul>
							<?php 
								
								$images = get_post_meta($post->ID, 'wpcf-client-logos');
									foreach ($images as $img) { ?>
									
								
							
									<li class="home-logos scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.7"
						data-translatey="60"><img src="<?php echo $img;?>"></li>
									<?php } ?>
									
							</ul>
							
						</div>
							
					</div>
				</section>
				
				
				
					
				</div>

	
		<script type="text/javascript">
			
			
			
  var bg = jQuery(".home-top");
  
jQuery(window).resize("resizeBackground");
function resizeBackground() {
    bg.height(jQuery(window).height());
}
resizeBackground();


$( window ).load(function() {
           var vidTop = document.getElementById('vidtop');
		   vidTop.play();            // The function returns the product of p1 and p2
		});


$(".playreel").click(function(){
	    $('#vidhero').addClass('playing');
	    $('.video-overlay').addClass('playing');
	    $('.playreel').addClass('playing');
	    $('.closevideo').addClass('playing');
	    $('.video-player').addClass('playing');
		$('.showreel-banner').addClass('playing');
		 	
		  
 
		if ($(window).width() < 768) {
			var targetHomeReel = $(".home-showreel").offset().top - 40;
		} else {
			var targetHomeReel = $(".home-showreel").offset().top - 50;
		};
	
	
	  $('html,body').animate({
	    scrollTop: targetHomeReel},
	    'slow');
	    
	    

});

$(".closevideo").click(function(){
    $('#vidhero').removeClass('playing');
	$('.video-overlay').removeClass('playing');
	$('.playreel').removeClass('playing');
	$('.closevideo').removeClass('playing');
	$('.video-player').removeClass('playing');
	$('.showreel-banner').removeClass('playing');
});




// init controller
	var controller = new ScrollMagic.Controller();
	
	var Reel = document.getElementById('reel');
	var vidHero1 = document.getElementById('vidhero1');
	var vidHero2 = document.getElementById('vidhero2');
	var vidHero3 = document.getElementById('vidhero3');
	 var vidTop = document.getElementById('vidtop');
		
	var tween1 = TweenMax.to("#animatelist1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween2 = TweenMax.to("#animatelist2", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween3 = TweenMax.to("#animatelist3", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween4 = TweenMax.to("#animatelist4", 1.2, {className: "+=isvisible", delay: 0.4, ease: Expo.easeOut});
	var tween5 = TweenMax.to("#animatelist5", 1.2, {className: "+=isvisible", delay: 0.4, ease: Expo.easeOut});
	var tween6 = TweenMax.to("#animatebox1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween7 = TweenMax.to("#animatebox2", 1.2, {className: "+=isvisible", delay: 0.2, ease: Expo.easeOut});
	var tween8 = TweenMax.to("#animatereel", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	
	var tween9 = TweenMax.to("#animatelistlink1", 1.2, {className: "+=isvisible", delay: 1, ease: Expo.easeOut});
	var tween10 = TweenMax.to("#animatelistlink2", 1.2, {className: "+=isvisible", delay: 1.4, ease: Expo.easeOut});
	// build scene
				var scene1 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
					
				var scene2 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
					
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);	
					
				var scene4 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween4)
					.addTo(controller);
					
				var scene5 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween5)
					.addTo(controller);
				
				
					
				var scene6 = new ScrollMagic.Scene({
					triggerElement: "#triggerhighlights",
					reverse: false,
					duration: 0
					})
					.setTween(tween6)
					.addTo(controller);
				var scene7 = new ScrollMagic.Scene({
					triggerElement: "#triggerhighlights",
					reverse: false,
					duration: 0
					})
					.setTween(tween7)
					.addTo(controller);
					
				var scene8 = new ScrollMagic.Scene({triggerElement: "#triggerreel", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 Reel.play();
				
					})
					.on("leave", function () {
							 Reel.pause();
				
					});
					
				var scene9 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween9)
					.addTo(controller);
				var scene10 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween10)
					.addTo(controller);
					
					
				
				
	
	
	</script>



<?php get_footer(); ?>
