<?php
/*
Template Name: Services
*/
?>

<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php 	
	$svccontent = get_post_meta($post->ID, 'wpcf-services-content', true);
	$svcprocess = get_post_meta($post->ID, 'wpcf-services-process', true);
	$svcstat1 = get_post_meta($post->ID, 'wpcf-services-stat-1', true);
	$svcstat2 = get_post_meta($post->ID, 'wpcf-services-stat-2', true);
	$svcsec1 = get_post_meta($post->ID, 'wpcf-services-section-1', true);
	$svcsec2 = get_post_meta($post->ID, 'wpcf-services-section-2', true);
	$svcspre = get_post_meta($post->ID, 'wpcf-services-pre-production', true);
	$svcspro = get_post_meta($post->ID, 'wpcf-services-production', true);
	$svcspost = get_post_meta($post->ID, 'wpcf-services-post-production', true);
?>
		

			<div id="content" class="nopadding">
			
			
			<section class="services-top">	
				
				
				<div 
						class="bgarrow1 scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
					    data-translatex="200"
						data-crop="true"
						data-opacity="0"
					></div>
					
					<div 
						class="bgarrow2 scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
					    data-translatex="500"
						data-crop="true"
						data-opacity="0"
					></div>
					
					
				
						
				<div class="services-top-container">
					
					
					<div id="inner-content" class="wrap wrap-service cf">
						<div class="home-title scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="-50">
						<h5 class="page-title" itemprop="headline"><?php the_title(); ?></h5>
						</div>
						<main id="main" class="m-all t-all d-all cf standard-body " role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
							

							

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

							<div class="home-title scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="-50">
								<section class="services-top-content cf" itemprop="articleBody">
									
									<?php the_content(); ?>
									
								</section> <?php // end article section ?>
							</div>
							</article>

						
						</main>
						
						
						<div class="home-title scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="40">
						<div class="service-items-container">
						
							<div class="button-group-service">
								
									<?php
							
							$args = array( 'posts_per_page' => 12, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'services' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$svcicon = get_post_meta($post->ID, 'wpcf-service-icon', true);
							$postname = $post->post_name;
							$countpost++;
							  setup_postdata( $post ); ?> 
							  
							  <?php if($countpost == 1){ ?> 
							   <button class="button button-<?php echo $countpost;?>a is-selected">
							  <?php  } else { ?>
							  <button class="button button-<?php echo $countpost;?>a">
							  <?php } ?>
							  
							   <span class="icon"><img src="<?php echo $svcicon;?>"></span>
							    <?php if($postname == 'motion-graphics'){?>
									  <span class="text motion">
								  <?php } else if ($postname == 'web-integrated-video') { ?>
								  	  <span class="text web">
								  <?php } else if ($postname == 'aerial-drone-videography') { ?>
								    	<span class="text drone">
								  <?php } else if ($postname == 'editing-post-production') { ?>
								     <span class="text editing">
								  <?php } else if ($postname == 'corporate-videos') { ?>
								       <span class="text corporate">
								  <?php } else if ($postname == 'short-films-commercials') { ?>
								  		<span class="text film">
								  <?php } else { ?>
								  	<span class="text">
								  <?php } ?>
								  
							   <?php the_title();?></span>
							   </button>
							   
								
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						  
						  </div>
						 

						<div class="main-carousel main-carousel-service" data-flickity='{ "cellAlign": "left", "autoPlay": 8000, "contain": true, "selectedAttraction": 0.05,
"friction": 0.8, "pauseAutoPlayOnHover": true, "dragThreshold": 15, "adaptiveHeight": true, "prevNextButtons": false, "pageDots": false}'>				
	
			<?php
							$countpost = 0;
							$args = array( 'posts_per_page' => 12, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'services' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$svcicon = get_post_meta($post->ID, 'wpcf-service-icon', true);
							$countpost++;
							$postname = $post->post_name;
							  setup_postdata( $post ); ?> 
							  
						
							<div class="carousel-cell carousel-cell-<?php echo $countpost;?>a">
							  <div class="service-box">
								  <?php if($postname == 'motion-graphics'){?>
									   <h3 class="motion">
								  <?php } else if ($postname == 'web-integrated-video') { ?>
								  		<h3 class="web">
								  <?php } else if ($postname == 'aerial-drone-videography') { ?>
								    	<h3 class="drone">
								  <?php } else if ($postname == 'editing-post-production') { ?>
								      <h3 class="editing">
								  <?php } else if ($postname == 'corporate-videos') { ?>
								        <h3 class="corporate">
								  <?php } else if ($postname == 'short-films-commercials') { ?>
								  		<h3 class="film">
								  <?php } else { ?>
								  	<h3>
								  <?php } ?>
								  
								 
									  
									  <?php the_title();?>
								  <span><img src="<?php echo $svcicon;?>"></span></h3>
								  
								  <hr>
								  <?php the_content();?>
								  </div>
						  </div>
								
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						</div>
						</div>
						</div>
				</div>
				
				
				</div>
				
			</section>
				
				
			<section class="services-2">
				
				<div class="services-2-bg scrollme animateme"
						data-when="span"
					    data-from="1"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-scale="1.3"
						data-translatey="-350"></div>
				<div id="inner-content" class="wrap wrap-small cf">
					<div class="m-all t-all d-all cf">
							
						<h2 class="services-title home-title scrollme animateme"
						data-when="enter"
					    data-from="0.7"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-scale="1.2"
						data-opacity="0.5"
						data-translatey="-150">From Pre to Post Production</h2>
					</div>
					<div id="animatedesc" class="m-all t-2of3 d-2of3 cf services-content-left">
						<div id="triggerdesc"></div>
						<?php echo apply_filters('the_content',$svcprocess); ?>
					</div>
					
					<div class="m-all t-1of3 d-1of3 last-col cf">
						<div id="triggerstats"></div>
						
						<ul class="stat">
							<li id="animatestats1"
						data-when="span"
					    data-from="1"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-translatey="80"><?php echo apply_filters('the_content',$svcstat1); ?></li>
							<li id="animatestats2"
						data-when="span"
					    data-from="1"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-translatey="80"><?php echo apply_filters('the_content',$svcstat2); ?></li>
						</ul>
						
						
						
					</div>
					
					
				</div>
			</section>
											
			<section class="services-4">
			
				
					
				<div id="inner-content" class="wrap wrap-small cf">
					<div class="m-all t-all d-all cf">
						<div class="home-title scrollme animateme"
						data-when="enter"
					    data-from="0.7"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0"
						data-translatey="-50">
						<?php echo apply_filters('the_content',$svcsec2); ?>
						</div>
					</div>
					
				</div>	
				
				<div id="inner-content" class="wrap wrap-fullwidth cf">
					<div id="trigger1"></div>
					<div class="production-workflow" id="animate1">
						
						<div class="line-bg">
							<div class="line line1"></div>
							<div class="line line2"></div>
							<div class="line line3"></div>
							<div class="line line4"></div>
							<div class="line line5"></div>
							<div class="line line6"></div>
							<div class="line line7"></div>
							<div class="line line8"></div>
							<div class="line line9"></div>
							<div class="line line10"></div>
							<div class="line line11"></div>
							<div class="line line12"></div>
							<div class="line line13"></div>
							<div class="line line14"></div>
						</div>
						
						<div class="line-fg">
							
							<div class="line-pre is-selected">
								<div class="line line1"></div>
								<div class="line line2"></div>
								<div class="line line2 line2-1"></div>
								<div class="line line3"></div>
								<div class="line line4"></div>
								<div class="line line4 line4-1"></div>
								
							</div>
							<div class="line-pro">
								<div class="line line5"></div>
								<div class="line line6"></div>
								<div class="line line7"></div>
								
							</div>
							<div class="line-post">
								<div class="line line8"></div>
								<div class="line line9"></div>
								<div class="line line9 line9-1"></div>
								<div class="line line10"></div>
								<div class="line line11"></div>
								<div class="line line12"></div>
								<div class="line line12 line12-1"></div>
								<div class="line line13"></div>
								
							</div>
							
							<div class="line fgline14 select-1"></div>
						</div>
						
					</div>
				</div>
				
				<div id="inner-content" class="wrap wrap-small cf">	
					<div class="m-all t-all d-all cf services-4-content" id="animate2">
						
						
						  <div class="button-group">
						    <button class="button button-1 is-selected">Pre-Production</button>
						    <button class="button button-2">Production</button>
						    <button class="button button-3">Post-Production</button>
						  </div>

						
						<div class="main-carousel main-carousel-workflow" data-flickity='{ "cellAlign": "center", "autoPlay": 8000, "contain": true, "selectedAttraction": 0.05,
"friction": 0.8, "pauseAutoPlayOnHover": true, "dragThreshold": 15, "prevNextButtons": false, "pageDots": false}'>
						  <div class="carousel-cell carousel-cell-1">
							  <div class="workflow-box"><?php echo apply_filters('the_content',$svcspre); ?></div>
						  </div>
						  <div class="carousel-cell carousel-cell-2">
							  <div class="workflow-box"><?php echo apply_filters('the_content',$svcspro); ?></div>
						  </div>
						  <div class="carousel-cell carousel-cell-3">
							 <div class="workflow-box"> <?php echo apply_filters('the_content',$svcspost); ?></div>
						  </div>
						</div>


					
						
					</div>
					
				</div>
				
			</section>
			
			
			<!-- <section class="services-3">
				<div id="inner-content" class="wrap wrap-home-wide cf">
				<video id="airpods" playsinline loop muted preload="auto" id="bgvid">
				    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/megax-banner.mp4" type="video/mp4">
				</video>
				</div>
				
				<div id="inner-content" class="wrap wrap-small cf">
					<div class="home-title scrollme animateme"
						data-when="span"
					    data-from="1"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-scale="0.9"
						data-translatey="60">
					<div class="m-all t-all d-all cf services-3-content">
						<?php echo apply_filters('the_content',$svcsec1); ?>
					</div>
					</div>
				</div>
				
			</section>	
				-->
				
				<!--
							<div id="trigger"></div>
							<div id="imagesequence">
								<img id="myimg" src="<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0000.jpg">
							</div>
							-->
							
		
		
			<?php endwhile; ?>
			<?php else : ?>		
			<?php endif; ?>
								

			</div>
			
			<script>
				
				
		
 
 
	// define images
	var images = [
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0000.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0001.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0002.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0003.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0004.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0005.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0006.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0007.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0008.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0009.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0010.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0011.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0012.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0013.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0014.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0015.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0016.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0017.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0018.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0019.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0020.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0021.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0022.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0023.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0024.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0025.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0026.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0027.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0028.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0029.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0030.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0031.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0032.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0033.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0034.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0035.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0036.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0037.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0038.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0039.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0040.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0041.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0042.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0043.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0044.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0045.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0046.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0047.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0048.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0049.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0050.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0051.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0052.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0053.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0054.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0055.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0056.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0057.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0058.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0059.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0060.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0061.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0062.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0063.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0064.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0065.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0066.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0067.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0068.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0069.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0070.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0071.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0072.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0073.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0074.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0075.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0076.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0077.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0078.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0079.jpg"
	];

	// TweenMax can tween any property of any object. We use this object to cycle through the array
	var obj = {curImg: 0};

	// create tween
	var tween = TweenMax.to(obj, 2.5,
		{
			curImg: images.length - 1,	// animate propery curImg to number of images
			roundProps: "curImg",				// only integers so it can be used as an array index
			repeat: 0,									// repeat 3 times
			immediateRender: true,			// load first image automatically
			ease: Linear.easeNone,			// show every image the same ammount of time
			onUpdate: function () {
			  $("#myimg").attr("src", images[obj.curImg]); // set the image source
			}
		}
	);
	
	var airpodVid = document.getElementById('airpods');
	var $lv = $('#airpods');

	// init controller
	var controller = new ScrollMagic.Controller();
	
	// build scene
	var scene = new ScrollMagic.Scene({triggerElement: "#trigger", duration: 0})
					.setTween(tween)
					.addIndicators() // add indicators (requires plugin)
					.addTo(controller);
					
	var scene2 = new ScrollMagic.Scene({triggerElement: "#airpods", duration: 0 })
					.addTo(controller)
					.addIndicators() // add indicators (requires plugin)
										
					.on("enter", function () {
						if(!$lv.hasClass('hasplayed')){
							 airpodVid.play();
							 $lv.addClass('hasplayed');
						} else {
							
						}
						
					})
					
				//.on("leave", function () {
				//		airpodVid.pause();
				//	 })

		
	var tween1 = TweenMax.to("#animate1", 1.2, {className: "+=isvisible", reverse:false, delay: 0, ease: Expo.easeOut});
	var tween2 = TweenMax.to("#animate2", 2, {className: "+=isvisible", reverse:false, offset:0 , delay: 1.5, ease: Expo.easeOut});
	var tween3 = TweenMax.to("#animatestats1", 1.2, {className: "+=isvisible", delay: 0.6, ease: Expo.easeOut});
	var tween4 = TweenMax.to("#animatestats2", 1.2, {className: "+=isvisible", delay: 0.9, ease: Expo.easeOut});
	var tween5 = TweenMax.to("#animatedesc", 1.2, {className: "+=isvisible", delay: 0.3, ease: Expo.easeOut});
	// build scene
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#trigger1",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
					
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#trigger1",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
				var scene1 = new ScrollMagic.Scene({
					triggerElement: "#triggerstats",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);
				var scene4 = new ScrollMagic.Scene({
					triggerElement: "#triggerstats",
					reverse: false,
					duration: 0
					})
					.setTween(tween4)
					.addTo(controller);
				var scene5 = new ScrollMagic.Scene({
					triggerElement: "#triggerdesc",
					reverse: false,
					duration: 0
					})
					.setTween(tween5)
					.addTo(controller);
			

				
</script>
			
			


<?php get_footer(); ?>

