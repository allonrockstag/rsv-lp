
<header class="header cd-header cd-header-trans" role="banner" itemscope itemtype="http://schema.org/WPHeader">

				<div id="inner-header" class="inner-header-appear">
				
					<?php // to use a image just replace the bloginfo('name') with your img src and remove the surrounding <p> ?>
					
					<div class="header-top">
					<p id="logo"><a href="<?php echo home_url(); ?>" rel="nofollow">
						<img src="<?php bloginfo( 'template_url' ); ?>/library/images/rsv-logo-white.png" />
							</a></p>
							
					<button id="searchtrigger" class="md-trigger md-trigger-white" data-modal="modal-7"><span></span></button>
					
					
						<nav class="nav nav-desktop" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
						
						
						<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => 'menu cf',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'TopNav' ,  // nav name
    					         'menu_class' => 'nav top-nav top-nav-white cf',               // adding custom nav class
    					         'theme_location' => 'main-nav'               // where it's located in the theme
						)); ?>

					</nav>
					
				
					</div>
					
				</div>
				
					
			</header>
			
			<nav class="nav nav-mobile" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				
					<ul class="cd-primary-nav">
						<div class="cd-primary-nav-header">
							<span>Navigate</span>
						<a id="menubutton" class="cd-primary-nav-trigger menubutton-trans" href="#0">
						<span class="cd-menu-icon cd-menu-icon"></span>
					</a> <!-- cd-primary-nav-trigger -->
						</div>
						
						
						<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => 'menu cf',                 // class of container (should you choose to use it)
    					         'menu' => __( 'The Main Menu', 'bonestheme' ),  // nav name
    					         'menu_class' => 'nav mobile-nav cf',               // adding custom nav class
    					         'theme_location' => 'main-nav',                 // where it's located in the theme
    					         'before' => '',                                 // before the menu
        			               'after' => '',                                  // after the menu
        			               'link_before' => '',                            // before each link
        			               'link_after' => '',                             // after each link
        			               'depth' => 0,                                   // limit the depth of the nav
    					         'fallback_cb' => ''                             // fallback function (if there is one)
						)); ?>
						
						
											
					</ul>
					
					</nav>