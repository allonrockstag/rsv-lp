			
			<div class="md-modal md-effect-7" id="modal-7"> 
			<div class="md-content">
				<div class="md-bg-container">
					<div class="md-bg"></div>
				</div>
				
					
				
					
						<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => 'menu cf',                 // class of container (should you choose to use it)
    					         'menu' => __( 'The Main Menu', 'bonestheme' ),  // nav name
    					         'menu_class' => 'nav mobile-nav cf',               // adding custom nav class
    					         'theme_location' => 'main-nav',                 // where it's located in the theme
    					         'before' => '',                                 // before the menu
        			               'after' => '',                                  // after the menu
        			               'link_before' => '',                            // before each link
        			               'link_after' => '',                             // after each link
        			               'depth' => 0,                                   // limit the depth of the nav
    					         'fallback_cb' => ''                             // fallback function (if there is one)
						)); ?>
						
						
							<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => '',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'Social' ,  // nav name
    					         'menu_class' => 'social-nav social-nav-off',               // adding custom nav class
    					         'theme_location' => 'main-nav'               // where it's located in the theme
						)); ?>


						
						
				<button class="md-close"><span></span></button>
					
				</div>
				
					
				
				
			</div>
		<div class="md-overlay"></div><!-- the overlay element -->
				
			</div>
			
		<div class="md-overlay"></div><!-- the overlay element -->
		
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/modalEffects-min.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/cssParser-min.js"></script>
		<script>
			// this is important for IEs
			var polyfilter_scriptpath = '/js/';
		</script>
		
		
		
	
	
		<footer class="footer" id="footer" role="contentinfo">
			
				<div class="footer-top">
					<div id="inner-footer" class="wrap cf">
						<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'footer-getquote' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							  setup_postdata( $post ); ?> 
							
								  <?php the_content(); ?>
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
					</div>
				</div>
				
				
				<div class="footer-middle">
					<div id="inner-footer" class="wrap cf">
					
					<div class="m-all t-1of7 d-1of7 footer-logo-container cf">
					
					<div class="footer-logo">
						<a href="<?php echo get_home_url(); ?>"><img src="<?php bloginfo( 'template_url' ); ?>/library/images/rsv-icon.png" /></a>
					</div>               	
					
					</div>
		
					
					<div class="m-all t-1of3 d-1of4 cf">
						
						
					  <nav role="navigation" class="footer-nav-main">
						<?php wp_nav_menu( array(
						'menu_class'    => 'footer-nav-2 cf',
						'menu' 			=> 'FooterNav2' 
						
						)); ?>
						</nav>   
					</div>
					
					<div class="m-all t-1of4 d-1of4 cf footer-nav-container">
							<h4>Explore</h4>
								<nav role="navigation" class="footer-nav-main">
						<?php wp_nav_menu(array(
    					'menu' => __( 'FooterNav', 'bonestheme' ),   // nav name
    					'menu_class' => 'footer-nav cf',            // adding custom nav class
    					'theme_location' => 'footer-links',             // where it's located in the theme
    					'before' => '',                                 // before the menu
    					'after' => '',                                  // after the menu
    					'link_before' => '',                            // before each link
    					'link_after' => '',                             // after each link
    					'depth' => 0,                                   // limit the depth of the nav
    					'fallback_cb' => 'bones_footer_links_fallback'  // fallback function
						)); ?>
						</nav>  
						
						
						</div>


					<div class="m-all t-1of4 d-1of4 last-col footer-contact">
						
						<h4>Contact Details</h4>
						
						<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'footer-contact' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							  setup_postdata( $post ); ?> 
							
								  <?php the_content(); ?>
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							
						<h4>Social</h4>
						<ul class="footer-social">
								<li class="footer-icon"><a href="https://www.facebook.com/foxesden.co/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<!--<li class="footer-icon"><a href="https://twitter.com/foxesden?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>-->
								<li class="footer-icon"><a href="https://www.youtube.com/channel/UCdjmRNHp3aOm4_zhOrNxhPg"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.instagram.com/foxesden.co/"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							</ul>
							
							
						              	
					
					</div>
					

					</div>
					
				</div>
				
				
				<div id="inner-footer" class="wrap cf footer-end">
				<div class="m-all t-all d-all cf">
					<p class="source-org copyright">&copy; <?php echo date('Y'); ?> Rockstagvid Pte Ltd. All Rights Reserved.&nbsp;&nbsp;<a href="<?php echo get_home_url(); ?>/privacy-policy">Privacy Policy</a>&nbsp;&nbsp;<a href="<?php echo get_home_url(); ?>/terms-of-use">Terms of Service</a></p>
				</div>
				</div>

			</footer>

		</div>

		<?php // all js scripts are loaded in library/bones.php ?>
		<?php wp_footer(); ?>
		
		
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/classie.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/fluidvids.min.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/flickity.pkgd.min.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/jquery.scrollme.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/tilt.jquery.js"></script>
		
		
		<script src="https://code.jquery.com/jquery-2.2.4.min.js"
			  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
			  crossorigin="anonymous"></script>
		<?php include('jscript-main.php');?>
	


	</body>

</html> <!-- end of site. what a ride! -->
