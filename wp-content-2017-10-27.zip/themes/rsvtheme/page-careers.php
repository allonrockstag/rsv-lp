<?php
/*
Template Name: Careers
*/
?>

<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<?php 	
	$bannertype = get_post_meta($post->ID, 'wpcf-career-banner-type', true);
	$careerintro = get_post_meta($post->ID, 'wpcf-career-intro', true);
	$careervideo = get_post_meta($post->ID, 'wpcf-career-video', true);
	$careerimage = get_post_meta($post->ID, 'wpcf-career-image', true);
	$careerform = get_post_meta($post->ID, 'wpcf-career-form', true);
?>

<?php endwhile; ?>
<?php else : ?>		
<?php endif; ?>
			
			
			<div id="content" class="contentgrey">
			<div class="standard-header careers-header">
				<div id="inner-content" class="wrap wrap-small cf">
					<div class="m-all t-all d-all cf">
						<div class="home-title scrollme animateme"
						data-when="span"
					    data-from="1"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="1"
						data-translatey="20">
						<h1 class="page-title" itemprop="headline">Careers at <span>RSV</span></h1>
						</div>
					</div>
				</div>
			</div>
	
				
				
				<div class="home-1-content scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-translatey="50">
			<section class="careers-banner" style="background-image:url(<?php echo $careerimage; ?>);">
				
				<?php if($bannertype == 1) { ?> <!-- VIDEO BANNER -->
					<video id="vidhero" muted loop preload="auto">
			    <source src="<?php echo $careervideo; ?>" type="video/mp4">
			</video>
					
				<?php } else if($bannertype == 2) { ?> <!-- IMAGE BANNER -->
					
					
				<?php } ?>
				
				
				<div id="inner-content" class="wrap wrap-small cf careers-banner-content">
					<div class="m-all t-all d-all cf">
						<div class="home-1-content scrollme animateme"
						data-when="enter"
					    data-from="0.2"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-translatey="20">
						<?php echo apply_filters('the_content',$careerintro); ?>
						</div>
					</div>
				</div>
			</section>	
			</div>
			
			<div class="home-1-content scrollme animateme"
						data-when="span"
					    data-from="0.5"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-translatey="80">
			<section class="careers">
				<div id="inner-content" class="wrap wrap-small cf careers-banner-content">
					<div class="m-all t-all d-all cf">
						<ul class="careers-list">
									<?php 
									
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 9,
									'paged' => $paged,
									'order'=> 'DESC',
									'post__not_in'  => array($sticky_posts,$post1,$post2,$post3) ,
									'orderby' => 'date',
									'post_type' => array('career')
									);
									$query = new WP_Query($args);
									?>


							<?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
								$content = get_the_content();
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$jobtype = get_post_meta($post->ID, 'wpcf-job-type', true);
									$location = get_post_meta($post->ID, 'wpcf-position-location', true);
									$status = get_post_meta($post->ID, 'wpcf-position-status', true);
									 $countpost++;
							?>
							
							
					
									
									<li id="animate<?php echo $countpost;?>">
									<div id="trigger<?php echo $countpost;?>"></div>
									
									  
							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
								<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									<p>
									<?php if($jobtype == 1){ ?>
										<span class="ft">Full Time</span>
									<?php } else if ($jobtype == 2){ ?>
										<span class="pt">Part Time</span>
									<?php } else if ($jobtype == 3){ ?>
										<span class="intern">Internship</span>
									<?php } else if ($jobtype == 4){ ?>
										<span class="contract">Contract</span>
									<?php } ?>
									
									<?php if($location == 1){ ?>
										<span class="location">Singapore</span>
									<?php } else if ($location == 2){ ?>
										<span class="location">Melbourne</span>
									<?php } else if ($location == 3){ ?>
										<span class="location">New Zealand</span>
									<?php } ?>
									</p>
									
							</article></a>
							
							
							 </li>	
										  
								
							
							<?php endwhile; ?>
							<!-- pagination -->
							
							<?php else : ?>
							<!-- No posts found -->
							<?php endif;
								wp_reset_postdata(); ?>
								
								
						</ul>
					</div>
					</div>
			</section>
			</div>
			<div class="dot-separator"></div>
			
			<section class="careers-bottom">
				<div id="inner-content" class="wrap wrap-small cf">
					<div class="m-all t-all d-all cf">
							<div class="share-box">
								<h3>Share This</h3>
							<ul class="footer-social">
								<li class="footer-icon"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.linkedin.com/cws/share?url=<?php echo get_permalink(); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							
							</ul>
								
							</div>
							<div class="career-form-container">
							<div class="career-form">
								<?php echo apply_filters('the_content',$careerform); ?>
							</div>
							</div>
					</div>
				</div>
			</section>
			
				<div id="inner-content" class="wrap wrap-small cf">

						<main id="main" class="m-all t-all d-all cf standard-body " role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

								<header class="article-header">

									
								</header> <?php // end article header ?>

								<section class="entry-content entry-content-small cf" itemprop="articleBody">
									
								
									
									<?php
										the_content();

									
										wp_link_pages( array(
											'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'bonestheme' ) . '</span>',
											'after'       => '</div>',
											'link_before' => '<span>',
											'link_after'  => '</span>',
										) );
									?>
									
									
								</section> <?php // end article section ?>

								

							</article>

							<?php endwhile; ?>
								
							<?php else : ?>

								<article id="post-not-found" class="hentry cf">
									<header class="article-header">
										<h1><?php _e( 'No Articles Yet', 'bonestheme' ); ?></h1>
									</header>
									<footer class="article-footer">
											<p>Can't find what you're looking for? Try looking again, or go back to our <a href="<?php echo get_home_url(); ?>">Home Page</a>.</p>
									</footer>
								</article>
								
								<?php endif; ?>

						</main>


				</div>

			</div>


<script>
	// init controller
	var controller = new ScrollMagic.Controller();


		
	var tween1 = TweenMax.to("#animatelist1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween2 = TweenMax.to("#animatelist2", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween3 = TweenMax.to("#animatelist3", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	
	var vidHero = document.getElementById('vidhero');
	var $vh = $('#vidhero');

	
	// build scene
				var scene1 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist1",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
					
				var scene2 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist2",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
					
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist3",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);	
					
				var scene4 = new ScrollMagic.Scene({triggerElement: "#triggervid1", duration: 800, offset: 400})
						.setPin("#pin1")
						.addTo(controller);
			
				var scene5 = new ScrollMagic.Scene({triggerElement: "#vidhero", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 vidHero.play();
				
					})
				
	

	</script>
<?php get_footer(); ?>

