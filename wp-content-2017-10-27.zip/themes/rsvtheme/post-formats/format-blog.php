<?php 
	$design = get_post_meta($post->ID, 'wpcf-article-design', true);  
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	?>
              <?php
                /*
                 * This is the default post format.
                 *
                 * So basically this is a regular post. if you don't want to use post formats,
                 * you can just copy ths stuff in here and replace the post format thing in
                 * single.php.
                 *
                 * The other formats are SUPER basic so you can style them as you like.
                 *
                 * Again, If you want to remove post formats, just delete the post-formats
                 * folder and replace the function below with the contents of the "format.php" file.
                */
              ?>
			  
			  	
			  	
				 
              <article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?> role="article">
	              
              	<!--<div itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
				    <div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">
				      <meta itemprop="url" content="https://foxesden.co/wp-content/themes/foxesdentheme/library/images/foxesden-logo-black.png">
				      <meta itemprop="width" content="500">
				      <meta itemprop="height" content="103">
				    </div>
				    <meta itemprop="name" content="Foxesden">
				  </div>
				-->

				
				
				<div class="m-all t-all d-all cf post-article">
					
					
				<?php if($design == '2'){ ?>
					<div class="post-video-area">
								<?php if($vidtype == '1' && !empty($vidyoutube)){ ?><?php echo $embed_code; ?><?php } ?>
								<?php if($vidtype == '2' && !empty($vidvimeo)){ ?><?php echo $embed_code2; ?><?php } ?>	
							</div>
							
							<?php if($vidtype == '1'){ ?>
								<div class="post-video-info"> 
								<h4><?php echo $ytdata->items[0]->snippet->title; ?><span class="views"><?php echo $json_data['items'][0]['statistics']['viewCount']; ?> Views</span></h4>
							<a href="<?php echo $vidyoutube; ?>"><span class="youtube-link">Watch on Youtube</span></a>
							</div>
							<?php } ?>
							
							
				<?php } ?>
								

					<?php if($design != '2'){ ?>
    		
	                <?php echo wp_get_attachment_image( $post->ID , array('700', '600'), "", array( "class" => "img-responsive" ) );  ?>
					
	                <?php if(has_post_thumbnail()) { ?>
	                
	                
	                <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 

		                $featuredImageAlt = get_post_meta( get_post_thumbnail_id($post->ID) );
		                $imageAlt = $featuredImageAlt['_wp_attachment_image_alt']['0']; // Display Alt text
		                $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "large" );
 						$image_width = $image_data[1]; 
						$image_height = $image_data[2]; 
	                ?> 
				                   <img class="article-feature-img" src="<?php echo $featuredImage; ?>" alt="<?php echo $imageAlt; ?>">
				              
				      <?php } ?>
				      
				      <?php } ?>
				      
				      
				      <?php if($design == '3'){ ?>
			            <?php if(has_post_thumbnail()) { ?>
		      
						    <!--<img class="article-feature-img-mobile" src="<?php echo $featuredImage; ?>" alt="<?php echo $imageAlt; ?>">-->
						<?php } ?>
					<?php } ?>

				
				<div class="m-all t-all d-1of8 cf share-bar">
				  
				
				  	<ul class="post-share" id="postshare">
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
						  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
	    <li class="share-pinterest"><a href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo $featuredImage; ?>&description=<?php the_title();?>" target="_blank"><span></span></a></li>
						  	<li class="share-comment"><a href="#comment"><span></span></a></li>
				  	</ul>
				  	<span class="spacer">&nbsp;</span>
			  	</div>
			  	
			  	
			  	<div class="m-all t-all d-all cf">
		
					 <section class="entry-content cf" itemprop="mainContentOfPage" content="WebPageElement">
	        
	               
                  <?php  the_content(); ?>

                </section> <?php // end article section ?>
                
			  	</div>
			  	
               
                
                
				</div>
                 
                 	
                 	
                 <div class="m-all t-all d-all cf">
	                
	                 <div class="dot-separator"></div>
	                  <section class="blog-bottom">
							<div class="share-box">
								<h3>Share This</h3>
							<ul class="footer-social">
								<li class="footer-icon"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.linkedin.com/cws/share?url=<?php echo get_permalink(); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							
							</ul>
								
							</div>
							
							
							<div class="blog-continue">
								<h3>Continue<br/>Reading</h3>
								
								<ul class="more-posts-list">
										
										
										<?php $posttype = get_post_type();
											$countpost = 0; ?>
										<?php 
									if( $posttype == 'post' ) { ?>
									    <?php  $loop = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 3, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?> 
									<?php } ?>
									
									
									<?php if ( $posttype !== 'post' && $posttype !== 'fashion-post' && $posttype !== 'beauty-post' && $posttype !== 'video' && $posttype !== 'art') { ?>
										<?php  $loop = new WP_Query( array( 'post_type' => array('post','fashion-post','beauty-post','art','lifestyle-post','adulting-post'), 'posts_per_page' => 5, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?>
										
									<?php } ?>
					<?php			
						if ( $loop->have_posts() ) :
				        while ( $loop->have_posts() ) : $loop->the_post();
				        $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
				        $design = get_post_meta($post->ID, 'wpcf-article-design', true); 
				        $post_type_name = get_post_type( $post->ID );
						$post_type = get_post_type_object( get_post_type($post) );
				        $countpost++; ?>
				            
				            
						 	  <li>
						 	  
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer"><div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div></div>	 </a>
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer"><div id="blockimage"></div></a>

				            <?php } ?>

							
								<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
													echo '<span>' . $term->name . '</span>';
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
                                  
									</p>
									
									
									<h2 class="entry-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
								
							</article>
						
							
							
										  </li>	
														            
				        <?php endwhile; ?>
				       
				  <?php  endif;
					  $countpost = 0;
				    wp_reset_postdata();
				?>

									</ul>

							</div>
							
						</section>
			
			
			
                <footer id="comment" class="article-footer">

                 

                  <?php the_tags( '<p class="tags"><span class="tags-title">' . __( '', 'bonestheme' ) . '</span> ', '', '</p>' ); ?>
                  	
                  	
              

                </footer> <?php // end article footer ?>
			  	</div>
              

              </article> <?php // end article ?>
              
              
			
			 
			 
		 	