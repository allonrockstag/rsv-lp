<?php 
	$design = get_post_meta($post->ID, 'wpcf-article-design', true);  
							$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
							$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
							$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
							$post_type_name = get_post_type( $post->ID );
							$post_type = get_post_type_object( get_post_type($post) );
							$embed_code = wp_oembed_get($vidyoutube);
							$embed_code2 = wp_oembed_get($vidvimeo);
	?>
              <?php
                /*
                 * This is the default post format.
                 *
                 * So basically this is a regular post. if you don't want to use post formats,
                 * you can just copy ths stuff in here and replace the post format thing in
                 * single.php.
                 *
                 * The other formats are SUPER basic so you can style them as you like.
                 *
                 * Again, If you want to remove post formats, just delete the post-formats
                 * folder and replace the function below with the contents of the "format.php" file.
                */
              ?>
			  
			  	
			  	
				 
              <article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?> role="article">
	              
              	<!--<div itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
				    <div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">
				      <meta itemprop="url" content="https://foxesden.co/wp-content/themes/foxesdentheme/library/images/foxesden-logo-black.png">
				      <meta itemprop="width" content="500">
				      <meta itemprop="height" content="103">
				    </div>
				    <meta itemprop="name" content="Foxesden">
				  </div>
				-->

				<div class="m-all t-all d-all cf post-article-normal">
					
					<div class="m-all t-all d-all cf post-header">
						
					
							
							
                <header class="article-header entry-header">
					
					<p class="byline entry-meta vcard"> </p>
                  
                  
                  <h1 class="entry-title single-title" itemprop="headline" rel="bookmark"><?php the_title(); ?></h1>
                  
                  <?php if ( has_excerpt() ) { ?>
					    <p class="excerpt" itemprop="description"><?php echo get_the_excerpt(); ?></p>
					<?php } else { ?>
					    
					<?php } ?>
				
				
				<span class="date">	
				
				<p class="update entry-time" datetime="<?php get_the_time('Y-m-d')?>" itemprop="datePublished"><?php the_time('F j, Y'); ?></p>
				</span>
				
				
				
				<span class="share-this">	
				
				<ul class="post-share-tablet">
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
						  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
	    <li class="share-pinterest"><a href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo $featuredImage; ?>&description=<?php the_title();?>" target="_blank"><span></span></a></li>
						  	<li class="share-comment"><a href="#comment"><span></span></a></li>
				  	</ul>
				</span>
				
                </header> <?php // end article header ?>
                
					</div>
				
				
				<div class="m-all t-all d-all cf post-article">
					
					
				<?php if($design == '2'){ ?>
					<div class="post-video-area">
								<?php if($vidtype == '1' && !empty($vidyoutube)){ ?><?php echo $embed_code; ?><?php } ?>
								<?php if($vidtype == '2' && !empty($vidvimeo)){ ?><?php echo $embed_code2; ?><?php } ?>	
							</div>
							
							<?php if($vidtype == '1'){ ?>
								<div class="post-video-info"> 
								<h4><?php echo $ytdata->items[0]->snippet->title; ?><span class="views"><?php echo $json_data['items'][0]['statistics']['viewCount']; ?> Views</span></h4>
							<a href="<?php echo $vidyoutube; ?>"><span class="youtube-link">Watch on Youtube</span></a>
							</div>
							<?php } ?>
							
							
				<?php } ?>
								

					<?php if($design != '2'){ ?>
    		
	                <?php echo wp_get_attachment_image( $post->ID , array('700', '600'), "", array( "class" => "img-responsive" ) );  ?>
					
	                <?php if(has_post_thumbnail()) { ?>
	                
	                
	                <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 

		                $featuredImageAlt = get_post_meta( get_post_thumbnail_id($post->ID) );
		                $imageAlt = $featuredImageAlt['_wp_attachment_image_alt']['0']; // Display Alt text
		                $image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "large" );
 						$image_width = $image_data[1]; 
						$image_height = $image_data[2]; 
	                ?> 
				                   <img class="article-feature-img" src="<?php echo $featuredImage; ?>" alt="<?php echo $imageAlt; ?>">
				              
				      <?php } ?>
				      
				      <?php } ?>
				      
				      
				      <?php if($design == '3'){ ?>
			            <?php if(has_post_thumbnail()) { ?>
		      
						    <!--<img class="article-feature-img-mobile" src="<?php echo $featuredImage; ?>" alt="<?php echo $imageAlt; ?>">-->
						<?php } ?>
					<?php } ?>

				
				<div class="m-all t-all d-1of8 cf share-bar">
				  
				
				  	<ul class="post-share" id="postshare">
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
						  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
	    <li class="share-pinterest"><a href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo $featuredImage; ?>&description=<?php the_title();?>" target="_blank"><span></span></a></li>
						  	<li class="share-comment"><a href="#comment"><span></span></a></li>
				  	</ul>
				  	<span class="spacer">&nbsp;</span>
			  	</div>
			  	
			  	
			  	<div class="m-all t-all d-all cf">
		
					 <section class="entry-content cf" itemprop="mainContentOfPage" content="WebPageElement">
	        
	               
                  <?php  the_content(); ?>

                </section> <?php // end article section ?>
                
			  	</div>
			  	
               
                
                
				</div>
                 
                 	<!--<div class="m-all t-1of3 d-1of4 last-col cf post-sidebar">
						<?php get_sidebar('post'); ?>
						
					</div> -->
                 	
                 	
                 <div class="m-all t-all d-all cf">
                <footer id="comment" class="article-footer">

                 

                  <?php the_tags( '<p class="tags"><span class="tags-title">' . __( '', 'bonestheme' ) . '</span> ', '', '</p>' ); ?>
                  	
                  	
              

                </footer> <?php // end article footer ?>
			  	</div>
                 
                 </div>
                 

              </article> <?php // end article ?>
              
              
			
			 
			 
		 	