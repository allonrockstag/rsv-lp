<?php get_header('white'); ?>

<?php
								
		if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
	elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
	else { $paged = 1; }

				$countpost = 0;
				$args3 = array(
					'posts_per_page' => 5,
					'paged' => $paged,
					'order'=> 'DESC',
					'orderby' => 'date',
					'offset' => 0,
					'ignore_sticky_posts' => 1,
					'post_type' => array('post') 
				);
				$args4 = array(
					'posts_per_page' => 5,
					'paged' => $paged,
					'order'=> 'DESC',
					'orderby' => 'date',
					'ignore_sticky_posts' => 1,
					'post_type' => array('post') 
				);
				
				?>
				
				<?php if ($paged == 1){?>
					<?php $query = new WP_Query($args3); ?>
				<?php } ?>
				<?php if ($paged > 1){?>
					<?php $query = new WP_Query($args4); ?>
				<?php } ?>

	



			<div id="content" class="contentgrey nopadding">
				
				<section class="blog-header">
					
					
								<?php if ($paged == 1){?>
									<!--<h2 class="category-title" itemprop="headline">More News</h2>-->
									
									<?php } else { ?> 
									<h2 class="blog-title" itemprop="headline">RSV Blog</h2>
									<h4 class="blog-title">Page <?php echo $paged;  ?></h4>
									<?php } ?>
									
									
						<?php if ($paged == 1){?>
						
						
					<div class="main-carousel blog-highlights" data-flickity='{ "cellAlign": "center", "autoPlay": 4000, "wrapAround": true, "selectedAttraction": 0.05,
"friction": 0.8, "pauseAutoPlayOnHover": true, "dragThreshold": 15, "prevNextButtons": true, "pageDots": true}'>
	
					
							<?php
						$countpost = 0;
						$args = array( 'posts_per_page' => 3, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('post'), 'offset' => 0 );
						$postslist = get_posts( $args );
						foreach ( $postslist as $post ) :
						$content = get_the_content();
						$content = strip_tags($content);
						$contentshort = substr($content, 0, 255);
						$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
						$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
						$post_type_name = get_post_type( $post->ID );
						$post_type = get_post_type_object( get_post_type($post) );
						$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
						$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
						$largeimgsrc = $largeimg[0];
						 $countpost++;
						  setup_postdata( $post ); ?> 
						  
						  
							  <div class="carousel-cell carousel-cell-<?php echo $countpost; ?>">
								  <div class="highlights-box">
									  <?php
								        if(has_post_thumbnail()) { ?>
								          
										 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
											 <div id="blockimagecontainer">
												 <div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div>
											</div>
										</a>		 
								
								    <?php } else { ?>
								     
								     	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
								         	<div id="blockimagecontainer">
								             	<div id="blockimage"></div>
								             </div>
								         </a>	
								
								    <?php } ?>
    
    
									  <article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
										
										<h2 class="entry-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
									<div class="block-excerpt">
										<?php if ( ! has_excerpt() ) {
											
											} else { 
											  the_excerpt(); }
											?>
									</div>
									
									
									
								</article>
								  </div>
							  </div>
						 
							  <?php
							endforeach; 
							wp_reset_postdata();
							?>
						
						
					</div>
					
			
				
					
				
				<?php } ?>
				<!-- END FIRST PAGE -->	 
					
					
				</section>	
				
					
				

					<div id="inner-content" class="wrap cf">

						<main id="main" class="m-all t-all d-all cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
																
							
							
							<ul class="blog-list">
								
								
									
																
								<?php  $countpost = 0; ?>
							
							<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
								$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
								$post_type_name = get_post_type( $post->ID );
								$post_type = get_post_type_object( get_post_type($post) );
								$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
								$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
									$largeimgsrc = $largeimg[0];
								 $countpost++;
							?>
						 	
						 	
						 	  <li>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
								<div id="blockimagecontainer">
<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
										<div id="blockimage"></div></div></a>	
				            <?php } ?>


							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">
							          
									<h2 class="entry-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
								
									<?php if ( ! has_excerpt() ) { ?>
										
										<? } else {  ?>
										      <div class="block-excerpt"><?php the_excerpt(); ?></div> 
										<?php } ?>
								
								
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
											
													echo '<span class="cat">' . $term->name . '</span>';
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
                                     <span class="time"><?php the_time('M j'); ?></span>
									</p>
							</article>
							
							
										  </li>						 	
						 	
							 <?php endwhile; ?>
									<!-- pagination -->
									<div class="pagination-custom">
									<?php 
									previous_posts_link('&laquo; Previous');
								    next_posts_link( 'More Articles &raquo;', $query->max_num_pages );
									
								    wp_reset_postdata();	
									?>
									</div>
									<?php else : ?>
									<!-- No posts found -->
									<?php $countpost=0; endif; ?>
		
									</ul>


						</main>


						
					</div>
				
				
				
						
						

			</div>


<?php get_footer(); ?>
