<?php
/*
 Template Name: Home
*/
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<?php 	$slides = get_post_meta($post->ID, 'wpcf-number-of-slides', true);
		$cell1title = get_post_meta($post->ID, 'wpcf-slide-1-title', true);
		$cell2title = get_post_meta($post->ID, 'wpcf-slide-2-title', true); 
		$cell3title = get_post_meta($post->ID, 'wpcf-slide-3-title', true);
		$cell1text = get_post_meta($post->ID, 'wpcf-slide-1-description', true); 
		$cell2text = get_post_meta($post->ID, 'wpcf-slide-2-description', true);
		$cell3text = get_post_meta($post->ID, 'wpcf-slide-3-description', true);
		$cell1image = get_post_meta($post->ID, 'wpcf-slide-1-background', true);
		$cell2image = get_post_meta($post->ID, 'wpcf-slide-2-background', true);
		$cell3image = get_post_meta($post->ID, 'wpcf-slide-3-background', true);
		$cell1link = get_post_meta($post->ID, 'wpcf-slide-1-link', true);
		$cell2link = get_post_meta($post->ID, 'wpcf-slide-2-link', true);
		$cell3link = get_post_meta($post->ID, 'wpcf-slide-3-link', true);
		$svc1 = get_post_meta($post->ID, 'wpcf-service-1', true);
		$svc2 = get_post_meta($post->ID, 'wpcf-service-2', true);
		$svc3 = get_post_meta($post->ID, 'wpcf-service-3', true);
		$svc4 = get_post_meta($post->ID, 'wpcf-service-4', true);
		$svc5 = get_post_meta($post->ID, 'wpcf-service-5', true);
		$svc6 = get_post_meta($post->ID, 'wpcf-service-6', true);
		$highlight1 = get_post_meta($post->ID, 'wpcf-highlight-1', true);
		$highlight2 = get_post_meta($post->ID, 'wpcf-highlight-2', true);
?>


	<?php get_header('white'); ?>


 <?php endwhile; ?>
								
<?php else : ?>

<?php endif; ?>
							
<?php 
	
	if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
					elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
					else { $paged = 1; }
	?>
					
					
		
				<div id="content" class="nopadding">
				<section class="home-top">
					<div class="home-top-container scrollme animateme"
						      data-when="span"
						      data-from="0"
						      data-to="1"
						      data-easing="linear"
						      data-rotatey="0"
							      data-opacity="0.3"
						      data-translatey="200">
						<div class="main-top-icons">
							
							
								<ul class="footer-social">
								<li class="footer-icon"><a href="https://www.facebook.com/foxesden.co/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<!--<li class="footer-icon"><a href="https://twitter.com/foxesden?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>-->
								<li class="footer-icon"><a href="https://www.youtube.com/channel/UCdjmRNHp3aOm4_zhOrNxhPg"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.instagram.com/foxesden.co/"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							</ul>
							
							
							</div>
						<div class="main-carousel" data-flickity='{ "cellAlign": "left", "autoPlay": 7000, "wrapAround": true, "contain": true, "selectedAttraction": 0.02,
"friction": 0.4, "pauseAutoPlayOnHover": false, "dragThreshold": 15}'>		
						<?php if($slides >= 1){ ?>
							<div class="carousel-cell carousel-cell-1" style="background-image:url(<?php echo $cell1image; ?>);">
							  <div class="carousel-overlay"></div>
							  <div class="carousel-text">
						
							  <h2><?php echo $cell1title; ?></h2>
							  <p><?php echo $cell1text; ?></p>
							  <h4><a href="<?php echo $cell1link; ?>">Play</a></h4>
							  </div>
						  </div>
						<?php } ?>
						  
						  <?php if($slides >= 2){ ?>
							<div class="carousel-cell carousel-cell-2" style="background-image:url(<?php echo $cell2image; ?>);">
							  <div class="carousel-overlay"></div>
							  <div class="carousel-text">
						
							  <h2><?php echo $cell2title; ?></h2>
							  <p><?php echo $cell2text; ?></p>
							  <h4><a href="<?php echo $cell2link; ?>">Play</a></h4>
							  </div>
						  </div>
						<?php } ?>
						
						 
						  <?php if($slides >= 3){ ?>
							<div class="carousel-cell carousel-cell-3" style="background-image:url(<?php echo $cell3image; ?>);">
							  <div class="carousel-overlay"></div>
							  <div class="carousel-text">
						
							  <h2><?php echo $cell3title; ?></h2>
							  <p><?php echo $cell3text; ?></p>
							  <h4><a href="<?php echo $cell3link; ?>">Play</a></h4>
							  </div>
						  </div>
						<?php } ?>
						
						</div>

					</div>
				</section>
				
				<section class="home-1">
					
					<div 
						class="home-bgarrow1 scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
					    data-translatex="300"
						data-crop="true"
						data-opacity="0"
					></div>
					
					<div 
						class="home-bgarrow2 scrollme animateme"
						data-when="span"
					    data-from="0"
					    data-to="1"
					    data-easing="linear"
					    data-translatex="500"
						data-crop="true"
						data-opacity="0"
					></div>
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-3of4 cf">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
				<div class="home-title scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-translatey="50">
							
				<h1>Rockstagvid Productions</h1>
				</div>
				
				
				<div class="home-1-content scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-translatey="70"
						>
						<?php the_content(); ?>
					</div>
				
				
				

			<?php endwhile; ?>
				
			<?php else : ?>

			<?php endif; ?>
			
						</div>
					</div>
					
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
							<div id="triggerlist"></div>
						<ul class="home-svc-list">
							<li id="animatelist1"><?php echo apply_filters('the_content',$svc1); ?></li>
							<li id="animatelist2"><?php echo apply_filters('the_content',$svc2); ?></li>
							<li id="animatelist3"><?php echo apply_filters('the_content',$svc3); ?></li>
							<li id="animatelist4"><?php echo apply_filters('the_content',$svc4); ?></li>
							<li id="animatelist5"><?php echo apply_filters('the_content',$svc5); ?></li>	
						</ul>
						</div>
					</div>
					
					<div class="showreel">
						<div id="triggerreel"></div>
						<div class="playshowreel" id="animatereel"></div>
					</div>
					
					
					
					<div class="home-highlights">
						<div id="triggerhighlights"></div>
						<ul>
							<li id="animatebox1">
								<span><?php echo apply_filters('the_content',$highlight1); ?></span>
							</li>
							<li id="animatebox2">
								<span><?php echo apply_filters('the_content',$highlight2); ?></span>
							</li>
						</ul>
						
					</div>
					
				</section>
				
				<section class="home-2">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<h2>Blog</h2>
					<ul class="home-blog-list">
						<li>
						<div class="list-item">
							<div id="blockimage"></div>
							<span>
								<h2>Color Grading vs Color Correction</h2>
								<p>Here's our explanation</p>
							</span>
						</div>
						</li>
						<li>
						<div class="list-item">
							<div id="blockimage"></div>
							<span>
								<h2>Color Grading vs Color Correction</h2>
								<p>Here's our explanation</p>
							</span>
						</div>
						</li>
						<li>
						<div class="list-item">
							<div id="blockimage"></div>
							<span>
								<h2>Color Grading vs Color Correction</h2>
								<p>Here's our explanation</p>
							</span>
						</div>
						</li>
						<li>
						<div class="list-item">
							<div id="blockimage"></div>
							<span>
								<h2>Color Grading vs Color Correction</h2>
								<p>Here's our explanation</p>
							</span>
						</div>
						</li>
						
					</ul>
					
					<h4><a href="<?php echo home_url(); ?>/blog">More from our Blog</a></h4>
					</div>
				</section>				
						
				<section class="home-3">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
							<div class="home-title scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-translatey="30">
							<h2>Clients & Partners</h2>
							</div>
								<ul>
							<?php 
								
								$images = get_post_meta($post->ID, 'wpcf-client-logos');
									foreach ($images as $img) { ?>
									
								
							
									<li class="home-logos scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.7"
						data-translatey="60"><img src="<?php echo $img;?>"></li>
									<?php } ?>
									
							</ul>
							
						</div>
							
					</div>
				</section>
				
				
				
					
				</div>

	
		<script type="text/javascript">
  var bg = jQuery(".home-top");
  
jQuery(window).resize("resizeBackground");
function resizeBackground() {
    bg.height(jQuery(window).height());
}
resizeBackground();


// init controller
	var controller = new ScrollMagic.Controller();


		
	var tween1 = TweenMax.to("#animatelist1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween2 = TweenMax.to("#animatelist2", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween3 = TweenMax.to("#animatelist3", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween4 = TweenMax.to("#animatelist4", 1.2, {className: "+=isvisible", delay: 0.4, ease: Expo.easeOut});
	var tween5 = TweenMax.to("#animatelist5", 1.2, {className: "+=isvisible", delay: 0.4, ease: Expo.easeOut});
	var tween6 = TweenMax.to("#animatebox1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween7 = TweenMax.to("#animatebox2", 1.2, {className: "+=isvisible", delay: 0.2, ease: Expo.easeOut});
	var tween8 = TweenMax.to("#animatereel", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	
	// build scene
				var scene1 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
					
				var scene2 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
					
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);	
					
				var scene4 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween4)
					.addTo(controller);
					
				var scene5 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist",
					reverse: false,
					duration: 0
					})
					.setTween(tween5)
					.addTo(controller);
					
				var scene6 = new ScrollMagic.Scene({
					triggerElement: "#triggerhighlights",
					reverse: false,
					duration: 0
					})
					.setTween(tween6)
					.addTo(controller);
				var scene7 = new ScrollMagic.Scene({
					triggerElement: "#triggerhighlights",
					reverse: false,
					duration: 0
					})
					.setTween(tween7)
					.addTo(controller);
				var scene8 = new ScrollMagic.Scene({
					triggerElement: "#triggerreel",
					reverse: false,
					duration: 0
					})
					.setTween(tween8)
					.addTo(controller);


	</script>



<?php get_footer(); ?>
