<?php
/*
 Template Name: Portfolio
*/
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<?php 	$slides = get_post_meta($post->ID, 'wpcf-number-of-slides', true);
?>


	<?php get_header('white'); ?>


 <?php endwhile; ?>
								
<?php else : ?>

<?php endif; ?>
							
<?php 
	
	if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
					elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
					else { $paged = 1; }
	?>
					
					
		
				<div id="content" class="nopadding">
				
				<script>
			// init controller
			var controller = new ScrollMagic.Controller();
		</script>
		
				
				<section class="portfolio-1">
					
					<div class="topspacer"></div>
					
					<div class="portfolio-type">
					<a href="#content"><div class="icon-white"><i class="fa fa-angle-up" aria-hidden="true"></i></div></a>
					<ul>
						<li class="selected"><a href="">All Projects</a></li>
						<li><a href="">Commercials</a></li>
						<li><a href="">Corporate Video</a></li>
						<li><a href="">Short Film</a></li>
						<li><a href="">Music Video</a></li>
						<li><a href="">VR / AR</a></li>
					</ul>
				</div>
				
				
					
					<div id="inner-content" class="wrap wrap-home-wide superwide cf">
						<div class="m-all t-all d-all cf">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
				
				
				
				<div class="portfolio-list">
						<?php the_content(); ?>
						
						
						
						<ul class="portfolio-list">
								
					
					
									<?php 
									
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 9,
									'paged' => $paged,
									'order'=> 'DESC',
									'post__not_in'  => array($sticky_posts,$post1,$post2,$post3) ,
									'orderby' => 'date',
									'post_type' => array('project')
									);
									$query = new WP_Query($args);
									?>


							<?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
								$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'medium', false, '' );
									$largeimgsrc = $largeimg[0]; 
									$brand = get_post_meta($post->ID, 'wpcf-brand-company', true);
									$year = get_post_meta($post->ID, 'wpcf-year-of-production', true);
									$leadtime = get_post_meta($post->ID, 'wpcf-lead-time', true);
									 $countpost++;
							?>
							
							
					
									
									<li id="animate<?php echo $countpost;?>"><div id="trigger<?php echo $countpost;?>"></div>
									  
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer" data-tilt data-tilt-glare="true" data-tilt-maxglare=".2" data-tilt-perspective="500" data-tilt-speed="1500" data-tilt-scale="1.05" data-tilt-max="3">
								
						
									<div class="play">
										<span class="play">Play</span>
										<span class="playhover"><i class="fa fa-play" aria-hidden="true"></i></span>
									</div>

<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div></div>
								</a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					       
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								
									<?php if ( ! has_excerpt() ) { ?>
										 <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<? } else {  ?>
										     
										<?php } ?>
										
										<?php if (!empty($brand)) { ?>
										 <p><?php echo $brand; ?></p>
										<?php } ?>
								
								
							</article></a>
							
							
										  </li>	
										  
								
							
							<?php endwhile; ?>
							<!-- pagination -->
							
							<?php else : ?>
							<!-- No posts found -->
							<?php endif;
								wp_reset_postdata(); ?>
								
								
									
								</ul>	
						
						
						
						
						
						
						
						
						</div>
				
				

			<?php endwhile; ?>
				
			<?php else : ?>

			<?php endif; ?>
			
						</div>
					</div>
				</section>
						
						
				<section class="home-3">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
							<div class="home-title scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.3"
						data-translatey="30">
							<h2>Clients & Partners</h2>
							</div>
								<ul>
							<?php 
								
								$images = get_post_meta($post->ID, 'wpcf-client-logos');
									foreach ($images as $img) { ?>
									
								
							
									<li class="home-logos scrollme animateme"
						data-when="enter"
					    data-from="0.8"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-opacity="0.7"
						data-translatey="60"><img src="<?php echo $img;?>"></li>
									<?php } ?>
									
							</ul>
							
						</div>
							
					</div>
				</section>
				
				
				
					
				</div>

	
		<script>
				// https://greensock.com/docs/Easing/Circ
				
				var tween1 = TweenMax.to("#animate1", 1.2, {className: "+=isvisible", reverse:false, delay: 0.5, ease: Expo.easeOut});
				var tween2 = TweenMax.to("#animate2", 1.2, {className: "+=isvisible", reverse:false, delay: 0.6, ease: Expo.easeOut});
				var tween3 = TweenMax.to("#animate3", 1.2, {className: "+=isvisible", reverse:false, delay: 0.7, ease: Expo.easeOut});
				var tween4 = TweenMax.to("#animate4", 1.2, {className: "+=isvisible", reverse:false, delay: 0.8, ease: Expo.easeOut});		
				var tween5 = TweenMax.to("#animate5", 1.2, {className: "+=isvisible", reverse:false, delay: 0.2, ease: Expo.easeOut});	
				var tween6 = TweenMax.to("#animate6", 1.2, {className: "+=isvisible", reverse:false, delay: 0.3, ease: Expo.easeOut});	
				var tween7 = TweenMax.to("#animate7", 1.2, {className: "+=isvisible", reverse:false, delay: 0.2, ease: Expo.easeOut});	
				var tween8 = TweenMax.to("#animate8", 1.2, {className: "+=isvisible", reverse:false, delay: 0.3, ease: Expo.easeOut});	
				var tween9 = TweenMax.to("#animate9", 1.2, {className: "+=isvisible", reverse:false, delay: 0.2, ease: Expo.easeOut});	
				var tween10 = TweenMax.to("#animate10", 1.2, {className: "+=isvisible", reverse:false, delay: 0.3, ease: Expo.easeOut});
							
				// build scene
				var scene = new ScrollMagic.Scene({
					triggerElement: "#trigger1",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
				var scene2 = new ScrollMagic.Scene({
					triggerElement: "#trigger1",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#trigger1",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);
				var scene4 = new ScrollMagic.Scene({
					triggerElement: "#trigger1",
					reverse: false,
					duration: 0
					})
					.setTween(tween4)
					.addTo(controller);
				var scene5 = new ScrollMagic.Scene({
					triggerElement: "#trigger5",
					reverse: false,
					duration: 0
					})
					.setTween(tween5)
					.addTo(controller);
				var scene6 = new ScrollMagic.Scene({
					triggerElement: "#trigger6",
					reverse: false,
					duration: 0
					})
					.setTween(tween6)
					.addTo(controller);
				var scene7 = new ScrollMagic.Scene({
					triggerElement: "#trigger7",
					reverse: false,
					duration: 0
					})
					.setTween(tween7)
					.addTo(controller);
				var scene8 = new ScrollMagic.Scene({
					triggerElement: "#trigger8",
					reverse: false,
					duration: 0
					})
					.setTween(tween8)
					.addTo(controller);
		</script>



<?php get_footer(); ?>
