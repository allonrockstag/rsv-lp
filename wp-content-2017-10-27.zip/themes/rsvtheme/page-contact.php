<?php
/*
Template Name: Contact
*/
?>

<?php get_header(); ?>


		

			<div id="content" class="contentgrey">


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							
							
<?php 
	$contactform = get_post_meta($post->ID, 'wpcf-contact-form', true);
	$contactoffice = get_post_meta($post->ID, 'wpcf-contact-office', true);
	$contactoffice2 = get_post_meta($post->ID, 'wpcf-contact-office-2', true);
	$contact1 = get_post_meta($post->ID, 'wpcf-contact-1', true);
	$contact2 = get_post_meta($post->ID, 'wpcf-contact-2', true);
	$contact3 = get_post_meta($post->ID, 'wpcf-contact-3', true);
	$contact4 = get_post_meta($post->ID, 'wpcf-contact-4', true);
?>

							
							
			<div class="standard-header">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
						<h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>
						</div>
					</div>
				</div>
			
			<section class="contact-1">
			<div id="inner-content" class="wrap wrap-home-wide cf">
			
				<div class="m-all t-all d-1of2 cf contact-1-left">
					<h2>Leave Us A Message</h2>
					<?php echo apply_filters('the_content',$contactform); ?>
				</div>
				<div class="m-all t-all d-1of2 last-col cf contact-1-right">
					<h2>Have a Chat at Our Office</h2>
					
					<div class="m-all t-1of2 d-all cf contact-1-right-container">
						<div class="m-all t-all d-1of3 cf">
							<h3>Singapore</h3>
						</div>
						<div class="m-all t-all d-2of3	 last-col cf">
							<?php echo apply_filters('the_content',$contactoffice); ?>
						</div>
					</div>
					<div class="m-all t-1of2 d-all cf contact-1-right-container">
						<div class="m-all t-all d-1of3 cf">
							<h3>Melbourne</h3>
						</div>
						<div class="m-all t-all d-2of3 last-col cf">
							<?php echo apply_filters('the_content',$contactoffice2); ?>
						</div>
					</div>
					
				</div>
			</div>
			</section>
			
			<section class="contact-2">
				<div id="inner-content" class="wrap wrap-home-wide cf">
					<div class="m-all t-1of2 d-1of4 cf contact-2-list">
						<?php echo apply_filters('the_content',$contact1); ?>
					</div>
					<div class="m-all t-1of2 d-1of4 cf contact-2-list">
						<?php echo apply_filters('the_content',$contact2); ?>
					</div>
					<div class="m-all t-1of2 d-1of4 cf contact-2-list">
						<?php echo apply_filters('the_content',$contact3); ?>
					</div>
					<div class="m-all t-1of2 d-1of4 last-col cf contact-2-list">
						<?php echo apply_filters('the_content',$contact4); ?>
					</div>
				</div>
			</section>
			
			<section class="contact-3">
				<div id="inner-content" class="wrap wrap-home-wide cf">
				<div class="m-all t-all d-all cf">
				
				</div>
				</div>
			</section>
			
			<section class="contact-3">
				<div id="inner-content" class="wrap wrap-home-wide cf">
				<div class="m-all t-all d-all cf">
					
				</div>
				</div>
			</section> 
				
		<!--	<video id="airpods" poster="<?php bloginfo( 'template_url' ); ?>/library/images/airpod-large.jpg" muted preload="auto" id="bgvid">
			    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/airpod-large.mp4" type="video/mp4">
			</video>
-->
											
		<!--	<div id="inner-content" class="wrap wrap-home-wide cf">

						<main id="main" class="m-all t-all d-all cf standard-body " role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
							
							<div id="trigger"></div>
							<div id="imagesequence">
								<img id="myimg" src="<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0000.jpg">
							</div>


							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

								<header class="article-header">

									
								</header> <?php // end article header ?>

								<section class="entry-content entry-content-small cf" itemprop="articleBody">
								
									
									<?php the_content(); ?>
									
									
								</section> <?php // end article section ?>

								

							</article>

							<?php endwhile; ?>
							<?php else : ?>
							<?php endif; ?>
								
						</main>


				</div>-->
				

			</div>
			
			<script>
	// define images
	var images = [
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0000.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0001.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0002.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0003.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0004.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0005.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0006.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0007.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0008.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0009.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0010.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0011.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0012.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0013.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0014.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0015.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0016.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0017.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0018.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0019.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0020.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0021.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0022.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0023.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0024.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0025.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0026.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0027.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0028.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0029.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0030.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0031.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0032.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0033.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0034.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0035.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0036.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0037.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0038.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0039.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0040.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0041.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0042.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0043.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0044.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0045.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0046.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0047.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0048.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0049.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0050.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0051.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0052.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0053.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0054.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0055.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0056.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0057.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0058.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0059.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0060.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0061.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0062.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0063.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0064.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0065.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0066.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0067.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0068.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0069.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0070.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0071.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0072.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0073.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0074.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0075.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0076.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0077.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0078.jpg",
		"<?php bloginfo( 'template_url' ); ?>/library/images/iphonex_sequence/iphonex-large0079.jpg"
	];

	// TweenMax can tween any property of any object. We use this object to cycle through the array
	var obj = {curImg: 0};

	// create tween
	var tween = TweenMax.to(obj, 2.5,
		{
			curImg: images.length - 1,	// animate propery curImg to number of images
			roundProps: "curImg",				// only integers so it can be used as an array index
			repeat: 0,									// repeat 3 times
			immediateRender: true,			// load first image automatically
			ease: Linear.easeNone,			// show every image the same ammount of time
			onUpdate: function () {
			  $("#myimg").attr("src", images[obj.curImg]); // set the image source
			}
		}
	);
	
	var airpodVid = document.getElementById('airpods');
	var $lv = $('#airpods');

	// init controller
	var controller = new ScrollMagic.Controller();
	
	// build scene
	var scene = new ScrollMagic.Scene({triggerElement: "#trigger", duration: 0})
					.setTween(tween)
					.addIndicators() // add indicators (requires plugin)
					.addTo(controller);
					
	var scene2 = new ScrollMagic.Scene({triggerElement: "#airpods", duration: 0 })
					.addTo(controller)
					.addIndicators() // add indicators (requires plugin)
										
					.on("enter", function () {
						if(!$lv.hasClass('hasplayed')){
							 airpodVid.play();
							 $lv.addClass('hasplayed');
						} else {
							
						}
						
					})
					
				//.on("leave", function () {
				//		airpodVid.pause();
				//	 })
				
</script>
			
			


<?php get_footer(); ?>

